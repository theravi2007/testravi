<?php
$subjectPrefix = 'idea2validate beta market size';
$emailTo = 'markus.deger@gmail.com';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name    = stripslashes(trim($_POST['form-name']));
    $email   = stripslashes(trim($_POST['form-email']));
    $subject = stripslashes(trim($_POST['form-subject']));
    $message = stripslashes(trim($_POST['form-message']));
    $pattern  = '/[\r\n]|Content-Type:|Bcc:|Cc:/i';

    if (preg_match($pattern, $name) || preg_match($pattern, $email) || preg_match($pattern, $subject)) {
        die("Header injection detected");
    }

    $emailIsValid = preg_match('/^[^0-9][A-z0-9._%+-]+([.][A-z0-9_]+)*[@][A-z0-9_]+([.][A-z0-9_]+)*[.][A-z]{2,4}$/', $email);

    if($name && $email && $emailIsValid && $subject && $message){
        $subject = "$subjectPrefix $subject";
        $body = "Nome: $name <br /> Email: $email <br /> Mensagem: $message";

        $headers  = 'MIME-Version: 1.1' . PHP_EOL;
        $headers .= 'Content-type: text/html; charset=utf-8' . PHP_EOL;
        $headers .= "From: $name <$email>" . PHP_EOL;
        $headers .= "Return-Path: $emailTo" . PHP_EOL;
        $headers .= "Reply-To: $email" . PHP_EOL;
        $headers .= "X-Mailer: PHP/". phpversion() . PHP_EOL;

        mail($emailTo, $subject, $body, $headers);
        $emailSent = true;
    } else {
        $hasError = true;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />	
	<title>Responsive Web Mobile - Langing Page</title>

	<!-- Set the viewport width to device width for mobile -->
  	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Included Bootstrap CSS Files -->
	<link rel="stylesheet" href="./js/bootstrap/css/bootstrap.min.css" />
	<link rel="stylesheet" href="./js/bootstrap/css/bootstrap-responsive.min.css" />

	<!-- Google Fonts -->
	<link href='http://fonts.googleapis.com/css?family=Titillium+Web:400,300' rel='stylesheet' type='text/css'>
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Raleway:400,300,700" rel="stylesheet" type="text/css">
	
	<!-- Css -->	
	<link rel="stylesheet" href="./css/style.css" />
    

</head>
<body>
<header>
	
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="header center-block">
					<p>&nbsp;</p>
            		<h2 class="main-title image"> You have an idea for an Internet or App
              			business? <br>
              			Get a first hand on your market size and find customers here!</h2>
            		<p>&nbsp;</p>
            		<div style="vertical-align:middle; text-align:center">
					<img src="img/i2v_white.png" align="middle">
            		</div>
      			<p>&nbsp;</p> 
            	<h3 class="main-title image"> We are running a closed beta!</h3>
            	<p>&nbsp;</p>
            	<a target="_blank" style="width: 199px;" class="btn btn-large btn-success" href="http://www.idea2validate.de">BETA</a>
				</div>
			</div>
		</div>
	</div>	
</header>

<div class="background theme">
	<div class="container">
		<div class="row center vspace30">
			<div class="col-md-12">
				<h1><span>Idea2Validate</span></h1>
				<p>Drop Us A Line</p>
			</div>
		

		<?php if(!empty($emailSent)): ?>
        
            <div class="alert alert-success text-center">Thank you!</div>
            </div>
    	
		<?php else: ?>
        <?php if(!empty($hasError)): ?>
        
            <div class="alert alert-danger text-center">Oops, something went wrong!</div>
            </div>
        <?php endif; ?>
    
        <form action="<?php echo $_SERVER['REQUEST_URI']; ?>" id="contact-form" class="form-horizontal" role="form" method="post">
            <div class="form-group">
                <label for="name" class="col-lg-2 control-label">Name</label>
                <div class="col-lg-10">
                    <input type="text" class="form-control required" id="form-name" name="form-name" placeholder="Name" />
                </div>
            </div>
            <div class="form-group">
                <label for="email" class="col-lg-2 control-label">Email</label>
                <div class="col-lg-10">
                    <input type="email" class="form-control required" id="form-email" name="form-email" placeholder="Email" />
                </div>
            </div>
            <div class="form-group">
                <label for="assunto" class="col-lg-2 control-label">Topic</label>
                <div class="col-lg-10">
                    <input type="text" class="form-control required" id="form-subject" name="form-subject" placeholder="Topic" />
                </div>
            </div>
            <div class="form-group">
                <label for="mensagem" class="col-lg-2 control-label">Message</label>
                <div class="col-lg-10">
                    <textarea class="form-control required" rows="3" id="form-message" name="form-message" placeholder="Message" /></textarea>
                </div>
            </div>
            <div class="form-group">
                <div class="col-lg-offset-2 col-lg-10">
                    <button type="submit" class="btn btn-default">Submit</button>
                </div>
            </div>
        </form>
        
        
    	<?php endif; ?>
    

		<div class="row center vspace30">
			<i>&copy;&nbsp;Copyright 2015 Idea2Validate <a href="impressum.html">Impressum</a></i>
		</div>
	
	</div>
    </div>
</div>	

<script src="./js/jquery-2.1.1.min.js"></script>
<script src="./js/bootstrap/js/bootstrap.min.js"></script>
<script src="./js/jquery-validate/assets/js/jquery.validate.min.js"></script>
<script src="./js/script.js"></script>

</body>
</html>