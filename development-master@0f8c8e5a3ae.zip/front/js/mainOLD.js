//var serviceUrl = 'https://i2v.herokuapp.com';
//var serviceUrl = 'http://shalaka-pc:18080';
var serviceUrl = 'http://192.168.0.102:18080';


var marketSizeFaktorPerPotentialUser = 15;

var initResults = true;
var progressDone = false;

var getPersonsDone = false;

var chartData = new Array();

var processCount = 0;

var geolatitude =null;

var geolongitude=null;



$(function() {
    $('#processBtn').click(startProgress);
    $('#marketSegmentInput').keypress(function(e) {
        if(e.which == 13) {
            startProgress();
        }
    });
	
	 $('#keyDistanceBtn').click(function() {
		// alert();
		 $.blockUI(	{ message: 'Start Analysing ...' } 	);
		 getLocation();
			
    });
	
    
});


function getLocation(position) {
	
    
    if (navigator.geolocation) {
		
        navigator.geolocation.getCurrentPosition(showPosition);
    }
}

function showPosition(position) {
   geolatitude = position.coords.latitude;
   geolongitude = position.coords.longitude;
  	getPersonsCountByDistance(geolatitude,geolongitude);
}

function getShareUrl() {
	var keywords =  $('input[name=searchWords]').val();
	var shareUrl = "http://www.idea2validate.com?keyword=" + keywords;
	return shareUrl;
}

function getShareImage(service){
	var img;
	switch (service) {
		case "facebook":
      img = "http://w.sharethis.com/images/facebook_32.png";
    	break;
    case "twitter":
      img = "http://w.sharethis.com/images/twitter_32.png";
      break;
    case "pinterest":
      img = "http://w.sharethis.com/images/pinterest_32.png";
      break; 
    case "linkedin":
      img = "http://w.sharethis.com/images/linkedin_32.png";
      break; 
    case "googleplus":
      img = "http://w.sharethis.com/images/googleplus_32.png";
      break; 
    case "email":
      img = "http://w.sharethis.com/images/email_32.png";
      break;   
	}
	return img; 	
}

function refreshShareUrl(){
	var shareUrl = getShareUrl();
	var htmlString = "<span id =\"twitter\" class=\"st_twitter_large\" st_url=\" " + shareUrl +"\" st_title=\"Market Size\"></span> \
										<span id =\"facebook\" class=\"st_facebook_large\" st_url=\" " + shareUrl +"\" st_title=\"Market Size\"></span> \
										<span id =\"linkedin\" class=\"st_linkedin_large\" st_url=\" " + shareUrl +"\" st_title=\"Market Size\"></span> \
										<span id =\"pinterest\" class=\"st_pinterest_large\" st_url=\" " + shareUrl +"\" st_title=\"Market Size\"></span> \
										<span id =\"googleplus\" class=\"st_googleplus_large\" st_url=\" " + shareUrl +"\" st_title=\"Market Size\"></span> \
										<span id =\"email\" class=\"st_email_large\" st_url=\" " + shareUrl +"\" st_title=\"Market Size\"></span>";
	$("#share_this").html(htmlString);
	
	$("#share_this").find('span').each(function(){
		    var img = getShareImage($(this).prop('id'));
		    
        stWidget.addEntry({
            "service":$(this).prop('id'),
            "element":this,
            "url":shareUrl,
            "title":$(this).prop('title'),
            "type":"large",
            "text":$(this).prop('displayText'),
            "image":img,
            "summary":"idea 2 validate"
        });
    });

}
// added the regional parameter into the x-axis legend
function startProgress() {
    var keywords = $('#marketSegmentInput').val();
    var legend = keywords   + " / " + $('#personaDescriptionRegionInput').find(":selected").text()
                            + " / " + $('#personaDescriptionAgeInput').find(":selected").text()
							+ " / " + $('#personaDescriptionGenderInput').find(":selected").text();
    var preKeywords =  $('input[name=searchWords]').val();
    var curKeyWords;
    if ((preKeywords != "")&&(preKeywords != " ")&&(preKeywords != null)){
    	curKeyWords = preKeywords + "," + keywords;
    }else{
    	curKeyWords = keywords;
    }	
    curKeyWords = curKeyWords.replace(/\s+/g, '');
    
    $('input[name=searchWords]').val(curKeyWords);
    refreshShareUrl();

    processCount = (parseInt(processCount) + 1);
    
    if (processCount > 0){
    	$('#personaDescriptionRegionInput').prop('disabled', false);
    	$('#personaDescriptionAgeInput').prop('disabled', false);
		$('#personaDescriptionGenderInput').prop('disabled', false);
    }

    if(keywords) {
        $('#marketSegmentGroup').removeClass('has-error');
        $('#marketSegmentGroup').addClass('has-success');
    } else {
        $('#marketSegmentGroup').removeClass('has-success');
        $('#marketSegmentGroup').addClass('has-error');
        return;
    }

    progressDone = false;
    $.blockUI(	{ message: 'Start Analysing ...' } 	);
    getPageLikeCount(keywords, function(res){
        progressDone = true;
	 var likes = filterLikes(res.count);
        doneProcessing(likes, legend);
        $('#segmentResult').text(keywords);
        $.unblockUI();
    });

    getPersonsDone = false;
    getPersons(keywords, function(res){
        getPersonsDone = true;
        addPersons(res);
    });
	
    
    $('#processBtn').prop('disabled', true);
    $('#processBarContainer').toggle(true);
    startFakeProcess(1, 5, setProgressDisplayToDone);
    
    $('#arrowLeft').fadeOut(1000);
    $('#arrowRight').fadeOut(1000);
}

function addPersons(res) {
    $('#keyUserTable').find('tr:gt(0)').remove();

    res.forEach(function(user){
        var userRow = '<tr>';
        userRow += wrapTd('<img width="38px" src="' + user.proifleImageUrl + '"></img>');
        userRow += wrapTd(user.retweets);
        userRow += wrapTd('<a target="_blank" href="https://twitter.com/' + user.screenName + '">' + user.screenName + '</a>');
        userRow += wrapTd('<a target="_blank" href="https://twitter.com/statuses/' + user.tweetId + '">Show Tweet</a>');
        userRow += '</tr>';
        $('#keyUserTable tr:last').after(userRow);
    });

    console.log(res);
}

function wrapTd(value) {
    return '<td>' + value + '</td>';
}

function doneProcessing(likeCount, keywords) {

    if(initResults) {
        resultInitTransitions();
        initResults = false;
        setTimeout(doneProcessing(likeCount, keywords), 1500);
        return;
    }
    
    setTimeout(function() {
            addNewDataSeries({name: keywords, y: calculateMarketSize(likeCount), likes: likeCount});
        }, 500);
    

    $('#headerInput').html('Change Variables And Process To Compare Markets');
}
//Update regional factors - STEVE
function filterLikes(likes) {
    var regionFactor;
    var ageFactor;
	var genderFactor;

		switch ($('#personaDescriptionRegionInput').find(":selected").val()) {
		case "AL":
         regionFactor = 1;
         break;
      case "AP":
         regionFactor = 0.288;
         break;
      case "EU":
         regionFactor = 0.241;
         break; 
      case "NA":
         regionFactor = 0.172;
         break; 
      case "ROW":
         regionFactor = 0.299;
         break;
		} 
		// Age filter - STEVE
		switch ($('#personaDescriptionAgeInput').find(":selected").val()) {
			case "AAL":
         ageFactor = 1;
         break;
      case "A16":
         ageFactor = 0.25;
         break; 
      case "A25":
         ageFactor = 0.29;
         break; 
      case "A35":
         ageFactor = 0.22;
         break; 
      case "A45":
         ageFactor = 0.15;
         break;
      case "A55":
         ageFactor = 0.09;
         break;
		} 	
		//Update gender filters STEVE
		switch ($('#personaDescriptionGenderInput').find(":selected").val()) {
			case "GAL":
         genderFactor = 1;
         break;
      case "GF":
         genderFactor = 0.53;
         break; 
      case "GM":
         genderFactor = 0.47;
         break; 
   		} 
		// Update filtered Likes calculation and integer parsing STEVE
		var filteredLikes = likes ? likes * regionFactor * ageFactor * genderFactor: 0;
		return parseInt(filteredLikes, 10);
}

function calculateMarketSize(likes) {
    var marketSize = likes ? likes * marketSizeFaktorPerPotentialUser : 0;
		
    return parseInt(marketSize, 10);
}

function getPageLikeCount(keywords, success) {
    $.ajax({
        url: serviceUrl + '/marketAnalysis/size?keywords=' + keywords,
        dataType: 'jsonp',
        success: success
    });
}

function getPersons(keywords, success) {
    $.ajax({
        url: serviceUrl + '/marketAnalysis/persons?keywords=' + keywords,
        dataType: 'jsonp',
        success: success
    });
}

function getPersonsCountByDistance(geolatitude,geolongitude) {

var keywords =  $('input[name=searchWords]').val();
	
    
    $.ajax({
        url: serviceUrl + '/marketAnalysis/personsCount?latitude='+geolatitude+'&longitude='+geolongitude+'&keywords='+keywords,
        dataType: 'jsonp'
    })
	.done(function(data){
		
		var count1=0, count2=0, count=3, count4=0, count5=0, countun=0;
		
		if(data.byDistanceOne !== null)
		{
			count1 = data.byDistanceOne[0].count;
			$('#keyDistanceList').append('<li id="oneKM"><a href="#">1km - '+count1+'</a></li>');
		}
		if( data.byDistanceTen !== null)
		{
			count2 = data.byDistanceTen[0].count;
			$('#keyDistanceList').append('<li id="tenKM"><a href="#">10km - '+count2+'</a></li>');
		}
		if(data.byDistanceHundred != null)
		{
			count3 = data.byDistanceHundred[0].count;
			$('#keyDistanceList').append('<li id="hundradKM"><a href="#">100km - '+count3+'</a></li>');
		}
		if(data.byDistanceThousand != null)
		{
			count4 = data.byDistanceThousand[0].count;
			$('#keyDistanceList').append('<li id="thousandKM"><a href="#">1000km - '+count4+'</a></li>');
		}
		if(data.byDistanceTenThousand != null)
		{
			count5 = data.byDistanceTenThousand[0].count;
			$('#keyDistanceList').append('<li id="tenthousandKM"><a href="#">10000km - '+count5+'</a></li>');
		}
		if(data.unknownUsers != null)
		{
			countun = data.unknownUsers[0].count;
			$('#keyDistanceList').append('<li id="unkownKM"><a href="#">Unknown - '+countun+'</a></li>');
		}
		
		$('#oneKM').click(function(){
			
			$('#keyUserTable').empty();
			//var tenLength = data.byDistanceOne[0].knownUsers.length;
			//alert(tenLength);
			
			for(var i =0 ; i<data.byDistanceOne[0].knownUsers.length; i++){
				$('#keyUserTable').append('<tr><td><img width="38px" src="' + data.byDistanceOne[0].knownUsers[i].proifleImageUrl + '"></img></td><td>' +data.byDistanceOne[0].knownUsers[i].retweets+'</td><td><a target="_blank" href="https://twitter.com/' + data.byDistanceOne[0].knownUsers[i].screenName + '">' + data.byDistanceOne[0].knownUsers[i].screenName + '</a></td><td><a target="_blank" href="https://twitter.com/statuses/' + data.byDistanceOne[0].knownUsers[i].tweetId + '">Show Tweet</a></td></tr>');
			}
			//$('#keyDistanceList').append('<li id="unkownKM"><a href="#">Unknown - '+countun+'</a></li>');
		});
		$('#tenKM').click(function(){
			$('#keyUserTable').empty();
			var tenLength = data.byDistanceTen[0].knownUsers.length;
			//alert(tenLength);
			
			for(var i =0 ; i<tenLength; i++){
				$('#keyUserTable').append('<tr><td><img width="38px" src="' + data.byDistanceTen[0].knownUsers[i].proifleImageUrl + '"></img></td><td>' +data.byDistanceTen[0].knownUsers[i].retweets+'</td><td><a target="_blank" href="https://twitter.com/' + data.byDistanceTen[0].knownUsers[i].screenName + '">' + data.byDistanceTen[0].knownUsers[i].screenName + '</a></td><td><a target="_blank" href="https://twitter.com/statuses/' + data.byDistanceTen[0].knownUsers[i].tweetId + '">Show Tweet</a></td></tr>');
			}
		});
		$('#hundradKM').click(function(){
			$('#keyUserTable').empty();
			var tenLength = data.byDistanceHundred[0].knownUsers.length;
			//alert(tenLength);
			
			for(var i =0 ; i<tenLength; i++){
				$('#keyUserTable').append('<tr><td><img width="38px" src="' + data.byDistanceHundred[0].knownUsers[i].proifleImageUrl + '"></img></td><td>' +data.byDistanceHundred[0].knownUsers[i].retweets+'</td><td><a target="_blank" href="https://twitter.com/' + data.byDistanceHundred[0].knownUsers[i].screenName + '">' + data.byDistanceHundred[0].knownUsers[i].screenName + '</a></td><td><a target="_blank" href="https://twitter.com/statuses/' + data.byDistanceHundred[0].knownUsers[i].tweetId + '">Show Tweet</a></td></tr>');
			}
		});
		$('#thousandKM').click(function(){
			$('#keyUserTable').empty();
			var tenLength = data.byDistanceThousand[0].knownUsers.length;
			//alert(tenLength);
			
			for(var i =0 ; i<tenLength; i++){
				$('#keyUserTable').append('<tr><td><img width="38px" src="' + data.byDistanceThousand[0].knownUsers[i].proifleImageUrl + '"></img></td><td>' +data.byDistanceThousand[0].knownUsers[i].retweets+'</td><td><a target="_blank" href="https://twitter.com/' + data.byDistanceThousand[0].knownUsers[i].screenName + '">' + data.byDistanceThousand[0].knownUsers[i].screenName + '</a></td><td><a target="_blank" href="https://twitter.com/statuses/' + data.byDistanceThousand[0].knownUsers[i].tweetId + '">Show Tweet</a></td></tr>');
			}
		});
		$('#tenthousandKM').click(function(){
			$('#keyUserTable').empty();
			//var tenLength = data.byDistanceTenThousand[0].knownUsers.length;
			//alert(tenLength);
			
			for(var i =0 ; i<data.byDistanceTenThousand[0].knownUsers.length; i++){
				$('#keyUserTable').append('<tr><td><img width="38px" src="' + data.byDistanceTenThousand[0].knownUsers[i].proifleImageUrl + '"></img></td><td>' +data.byDistanceTenThousand[0].knownUsers[i].retweets+'</td><td><a target="_blank" href="https://twitter.com/' + data.byDistanceTenThousand[0].knownUsers[i].screenName + '">' + data.byDistanceTenThousand[0].knownUsers[i].screenName + '</a></td><td><a target="_blank" href="https://twitter.com/statuses/' + data.byDistanceTenThousand[0].knownUsers[i].tweetId + '">Show Tweet</a></td></tr>');
			}
		});
		/*$('#unkownKM').click(function(){
			alert("6");
		})*/;
		
		
		$.unblockUI();
	})
	.fail(function() {
    	alert( "error" );
   	});
	
	//getLocation();
}

//Column array colour set blue if in the corridor and red if outside -STEVE
function addNewDataSeries(data) {
    data.color = '#A9FF96';
    var newDataArray = [data];
    for (var i = 0; i < chartData.length; i++) {
        var series = chartData[i];
        if(series.y < 5000000 || series.y > 100000000){
        	series.color = 'red';
        }else{
        	series.color = '#7CB5EC';	
        }        
        newDataArray.push(series);
    }
    chartData = newDataArray;
    
    printMarketSizeChart(chartData);

    setTimeout(function() {
        var chart = $("#marketSizeChart").highcharts();
        chart.series[0].data[0].setState('hover');
        chart.tooltip.refresh(chart.series[0].data[0]);
    }, 1500);
}

function setProgressDisplayToDone() {
    $('#processBtn').prop('disabled', false);
    $('#processBarContainer').toggle(false);
    $('#processBar').width('0%');
}

function resultInitTransitions() {
    setTimeout(function() {
        $('#inputPanel').toggleClass('col-sm-6 col-sm-5');
        
        setTimeout(displayResults, 600);
    }, 500);
}

function displayResults() {
    $('#resultPanel').fadeIn(1000);
}

function startFakeProcess(counter, steps, doneCallback) {
    if(counter > steps || progressDone) {
        doneCallback();
    } else {
        setTimeout(function() {
            if(!progressDone) {
                var step = (100 / steps) * counter;
                $('#processBar').width(step + '%');
            }
            startFakeProcess(counter + 1, steps, doneCallback);
        }, 200);
    }
}

function printMarketSizeChart(data) {
    $('#marketSizeChart').highcharts({
        chart: {
            type: 'column'
        },
        title: {
			text : '<span style="font-size: 15px;color: black;">Indicative Market Size in US$ (Only FB-Users & Referal income)</span>'
            
        },
        credits: false,
        legend: {
            enabled: false
        },
        xAxis: {
            type: 'category',
            labels: {
                rotation: -45,
                style: {
                    fontSize: '13px',
                    fontFamily: 'Verdana, sans-serif'
                }
            }
        },
        yAxis: {
            min: 0,
            title: {
               				text : '<span style="font-size: 11px;color: orange;">StartUp Corridor 5-100M | Competition Intensity</span>'
            },
			// Creation of startup corridor Lines for the visulization 04/05/2015
			plotLines : [{
				value : 5000000,
				color : 'orange',
				dashStyle : 'dot',
				width : 2,
				label : {
					useHTML: true,
					text : '<span style="font-size: 8px;font-style: italic;color: black;">if < 5Mio$,increase market</span>'
				},
				zIndex: 5
			}, {
				value : 100000000,
				color : 'orange',
				dashStyle : 'dot',
				width : 2,
				label : {
					useHTML: true,
					text : '<span style="font-size: 8px;font-style: italic;color: black;">If >100Mio$, segment market</span>'
				},
				zIndex: 5
			}]
        },
        tooltip: {
            pointFormat: 'Market Size: <b>{point.y}</b> Facebook Likes: <b>{point.likes}</b>'
        },
        plotOptions: {
            series: {
                borderWidth: 0,
                pointPadding: 0.2,
                dataLabels: {
                    enabled: true,
                    format: '{point.y:,.0f}'
                }
            }
        },
        series: [{
            data: data
			  
        }]
    });
}