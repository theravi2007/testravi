var serviceUrl = 'https://rocky-sierra-8495.herokuapp.com';
//var serviceUrl = 'http://localhost:18080';


var marketSizeFaktorPerPotentialUser = 15;

var initResults = true;
var progressDone = false;

var getPersonsDone = false;

var chartData = new Array();

var processCount = 0;

$(function() {
    $('#processBtn').click(startProgress);
    $('#marketSegmentInput').keypress(function(e) {
        if(e.which == 13) {
            startProgress();
        }
    });
});

function getShareUrl() {
	var keywords =  $('input[name=searchWords]').val();
	var shareUrl = "http://www.idea2validate.com?keyword=" + keywords;
	return shareUrl;
}

function getShareImage(service){
	var img;
	switch (service) {
		case "facebook":
      img = "http://w.sharethis.com/images/facebook_32.png";
    	break;
    case "twitter":
      img = "http://w.sharethis.com/images/twitter_32.png";
      break;
    case "pinterest":
      img = "http://w.sharethis.com/images/pinterest_32.png";
      break; 
    case "linkedin":
      img = "http://w.sharethis.com/images/linkedin_32.png";
      break; 
    case "googleplus":
      img = "http://w.sharethis.com/images/googleplus_32.png";
      break; 
    case "email":
      img = "http://w.sharethis.com/images/email_32.png";
      break;   
	}
	return img; 	
}

function refreshShareUrl(){
	var shareUrl = getShareUrl();
	var htmlString = "<span id =\"twitter\" class=\"st_twitter_large\" st_url=\" " + shareUrl +"\" st_title=\"Market Size\"></span> \
										<span id =\"facebook\" class=\"st_facebook_large\" st_url=\" " + shareUrl +"\" st_title=\"Market Size\"></span> \
										<span id =\"linkedin\" class=\"st_linkedin_large\" st_url=\" " + shareUrl +"\" st_title=\"Market Size\"></span> \
										<span id =\"pinterest\" class=\"st_pinterest_large\" st_url=\" " + shareUrl +"\" st_title=\"Market Size\"></span> \
										<span id =\"googleplus\" class=\"st_googleplus_large\" st_url=\" " + shareUrl +"\" st_title=\"Market Size\"></span> \
										<span id =\"email\" class=\"st_email_large\" st_url=\" " + shareUrl +"\" st_title=\"Market Size\"></span>";
	$("#share_this").html(htmlString);
	
	$("#share_this").find('span').each(function(){
		    var img = getShareImage($(this).prop('id'));
		    
        stWidget.addEntry({
            "service":$(this).prop('id'),
            "element":this,
            "url":shareUrl,
            "title":$(this).prop('title'),
            "type":"large",
            "text":$(this).prop('displayText'),
            "image":img,
            "summary":"idea 2 validate"
        });
    });

}

function startProgress() {
    var keywords = $('#marketSegmentInput').val();
    var legend = keywords   + " / " + $('#personaDescriptionRegionInput').find(":selected").text()
                            + " / " + $('#personaDescriptionAgeInput').find(":selected").text();
    
    var preKeywords =  $('input[name=searchWords]').val();
    var curKeyWords;
    if ((preKeywords != "")&&(preKeywords != " ")&&(preKeywords != null)){
    	curKeyWords = preKeywords + "," + keywords;
    }else{
    	curKeyWords = keywords;
    }	
    curKeyWords = curKeyWords.replace(/\s+/g, '');
    
    $('input[name=searchWords]').val(curKeyWords);
    refreshShareUrl();

    processCount = (parseInt(processCount) + 1);
    
    if (processCount > 0){
    	$('#personaDescriptionRegionInput').prop('disabled', false);
    	$('#personaDescriptionAgeInput').prop('disabled', false);
    }

    if(keywords) {
        $('#marketSegmentGroup').removeClass('has-error');
        $('#marketSegmentGroup').addClass('has-success');
    } else {
        $('#marketSegmentGroup').removeClass('has-success');
        $('#marketSegmentGroup').addClass('has-error');
        return;
    }

    progressDone = false;
    $.blockUI(	{ message: 'Start Analysing ...' } 	);
    getPageLikeCount(keywords, function(res){
        progressDone = true;
	 var likes = filterLikes(res.count);
        doneProcessing(likes, legend);
        $('#segmentResult').text(keywords);
        $.unblockUI();
    });

    getPersonsDone = false;
    getPersons(keywords, function(res){
        getPersonsDone = true;
        addPersons(res);
    });
    
    $('#processBtn').prop('disabled', true);
    $('#processBarContainer').toggle(true);
    startFakeProcess(1, 5, setProgressDisplayToDone);
    
    $('#arrowLeft').fadeOut(1000);
    $('#arrowRight').fadeOut(1000);
}

function addPersons(res) {
    $('#keyUserTable').find('tr:gt(0)').remove();

    res.forEach(function(user){
        var userRow = '<tr>';
        userRow += wrapTd('<img width="38px" src="' + user.proifleImageUrl + '"></img>');
        userRow += wrapTd(user.retweets);
        userRow += wrapTd('<a target="_blank" href="https://twitter.com/' + user.screenName + '">' + user.screenName + '</a>');
        userRow += wrapTd('<a target="_blank" href="https://twitter.com/statuses/' + user.tweetId + '">Show Tweet</a>');
        userRow += '</tr>';
        $('#keyUserTable tr:last').after(userRow);
    });

    console.log(res);
}

function wrapTd(value) {
    return '<td>' + value + '</td>';
}

function doneProcessing(likeCount, keywords) {

    if(initResults) {
        resultInitTransitions();
        initResults = false;
        setTimeout(doneProcessing(likeCount, keywords), 1500);
        return;
    }
    
    setTimeout(function() {
            addNewDataSeries({name: keywords, y: calculateMarketSize(likeCount), likes: likeCount});
        }, 500);
    

    $('#headerInput').html('Change Variables And Process To Compare Markets');
}

function filterLikes(likes) {
    var regionFactor;
    var ageFactor;

		switch ($('#personaDescriptionRegionInput').find(":selected").val()) {
			case "AL":
         regionFactor = 1;
         break;
      case "AP":
         regionFactor = 0.45;
         break;
      case "EU":
         regionFactor = 0.23;
         break; 
      case "NA":
         regionFactor = 0.12;
         break; 
      case "LA":
         regionFactor = 0.10;
         break; 
      case "ME":
         regionFactor = 0.10;
         break;
		} 
		
		switch ($('#personaDescriptionAgeInput').find(":selected").val()) {
			case "AAL":
         ageFactor = 1;
         break;
      case "A16":
         ageFactor = 0.25;
         break; 
      case "A25":
         ageFactor = 0.29;
         break; 
      case "A35":
         ageFactor = 0.22;
         break; 
      case "A45":
         ageFactor = 0.15;
         break;
      case "A55":
         ageFactor = 0.09;
         break;
		} 	
		
		var filteredLikes = likes ? likes * regionFactor * ageFactor : 0;
		return parseInt(filteredLikes, 10);
}

function calculateMarketSize(likes) {
    var marketSize = likes ? likes * marketSizeFaktorPerPotentialUser : 0;
		
    return parseInt(marketSize, 10);
}

function getPageLikeCount(keywords, success) {
    $.ajax({
        url: serviceUrl + '/marketAnalysis/size?keywords=' + keywords,
        dataType: 'jsonp',
        success: success
    });
}

function getPersons(keywords, success) {
    $.ajax({
        url: serviceUrl + '/marketAnalysis/persons?keywords=' + keywords,
        dataType: 'jsonp',
        success: success
    });
}

function addNewDataSeries(data) {
    data.color = '#A9FF96';
    var newDataArray = [data];
    for (var i = 0; i < chartData.length; i++) {
        var series = chartData[i];
        series.color = '#7CB5EC';
        newDataArray.push(series);
    }
    chartData = newDataArray;
    
    printMarketSizeChart(chartData);

    setTimeout(function() {
        var chart = $("#marketSizeChart").highcharts();
        chart.series[0].data[0].setState('hover');
        chart.tooltip.refresh(chart.series[0].data[0]);
    }, 1500);
}

function setProgressDisplayToDone() {
    $('#processBtn').prop('disabled', false);
    $('#processBarContainer').toggle(false);
    $('#processBar').width('0%');
}

function resultInitTransitions() {
    setTimeout(function() {
        $('#inputPanel').toggleClass('col-sm-6 col-sm-5');
        
        setTimeout(displayResults, 600);
    }, 500);
}

function displayResults() {
    $('#resultPanel').fadeIn(1000);
}

function startFakeProcess(counter, steps, doneCallback) {
    if(counter > steps || progressDone) {
        doneCallback();
    } else {
        setTimeout(function() {
            if(!progressDone) {
                var step = (100 / steps) * counter;
                $('#processBar').width(step + '%');
            }
            startFakeProcess(counter + 1, steps, doneCallback);
        }, 200);
    }
}

function printMarketSizeChart(data) {
    $('#marketSizeChart').highcharts({
        chart: {
            type: 'column'
        },
        title: {
			text : '<span style="font-size: 15px;color: black;">Indicative Market Size in US$ (Only FB-Users & Referal income)</span>'
            
        },
        credits: false,
        legend: {
            enabled: false
        },
        xAxis: {
            type: 'category',
            labels: {
                rotation: -45,
                style: {
                    fontSize: '13px',
                    fontFamily: 'Verdana, sans-serif'
                }
            }
        },
        yAxis: {
            min: 0,
            title: {
               				text : '<span style="font-size: 11px;color: orange;">StartUp Corridor 5-100M | Competition Intensity</span>'
            },
			// Creation of startup corridor Lines for the visulization 04/05/2015
			plotLines : [{
				value : 5000000,
				color : 'orange',
				dashStyle : 'dot',
				width : 2,
				label : {
					useHTML: true,
					text : '<span style="font-size: 8px;font-style: italic;color: black;">if < 5Mio$,increase market</span>'
				},
				zIndex: 5
			}, {
				value : 100000000,
				color : 'orange',
				dashStyle : 'dot',
				width : 2,
				label : {
					useHTML: true,
					text : '<span style="font-size: 8px;font-style: italic;color: black;">If >100Mio$, segment market</span>'
				},
				zIndex: 5
			}]
        },
        tooltip: {
            pointFormat: 'Market Size: <b>{point.y}</b> Facebook Likes: <b>{point.likes}</b>'
        },
        plotOptions: {
            series: {
                borderWidth: 0,
                pointPadding: 0.2,
                dataLabels: {
                    enabled: true,
                    format: '{point.y:,.0f}'
                }
            }
        },
        series: [{
            data: data
        }]
    });
}