//var serviceUrl = 'https://rocky-taiga-2502.herokuapp.com/';
//var serviceUrl = 'https://lit-tundra-3815.herokuapp.com/';
var serviceUrl = 'https://localhost/staging';
// var serviceUrl = 'http://192.168.0.109:8091';


var marketSizeFaktorPerPotentialUser = 15;
var initResults = true;
var progressDone = false;
var getPersonsDone = false;
var getFacebooPersonsDone = false;
var chartData = new Array();
var processCount = 0;
var startProgressAlready = false;

var geolatitude;
var geolongitude;
var geolatLon = false;

var geoKeyword;

var map;
var marker;
var infowindow;

var loopCount = 0;

var keywords;
var region;
var age;
var gender;
var localStorageFoundCount = false;
var localStorageFacebookResult = false;
var localStorageTwitterResult = false;

$(function() {

	var keywordsQuery = jQuery.query.get("key");
	var regionQuery = jQuery.query.get("region");
	var ageQuery = jQuery.query.get("age");
	var genderQuery = jQuery.query.get("gender");
	var hitBackQuery = jQuery.query.get("hitBack");
	var channelQuery = jQuery.query.get("channel");

	keywords = keywordsQuery.split('|');
	region = regionQuery.split('|');
	age = ageQuery.split('|');
	gender = genderQuery.split('|');

	if (keywords != "") {
		if (!startProgressAlready) {
			$.blockUI({
				message : 'Start Analysing ...'
			});
			startProgressAlready = true;
		}
		if (hitBackQuery != "") {
			$.ajax({
				url : serviceUrl
						+ 'marketAnalysis/countdetail?callback=10&channel='
						+ channelQuery + '&keywordList=' + keywords,
				dataType : 'jsonp'
			});
		}
		loopStart(loopCount);
	}

	$('#processBtn')
			.click(
					function() {
						$('#table').addClass("active");
						$('#table').removeClass("hidden");
						$('#gmap').addClass("hidden");
						$('#tabsBtn2').addClass("hidden");
						geolatLon = false;
						$('#keyDistanceList').empty();

						// ($('#marketSegmentInput').val());

						// searchCount($('#marketSegmentInput').val());
						if (!startProgressAlready) {
							$.blockUI({
								message : 'Start Analysing ...'
							});
							startProgressAlready = true;
						}
						$
								.ajax(
										{
											url : serviceUrl
													+ '/marketAnalysis/searchkeywordcount?keyword='
													+ $('#marketSegmentInput')
															.val(),
											dataType : 'jsonp'
										}).done(function(data) {
									refreshUrl();
								});

					});

	$('#marketSegmentInput')
			.keypress(
					function(e) {
						if (e.which == 13) {
							$('#table').addClass("active");
							$('#table').removeClass("hidden");
							$('#gmap').addClass("hidden");
							$('#tabsBtn2').addClass("hidden");
							geolatLon = false;
							$('#keyDistanceList').empty();
							// searchCount($('#marketSegmentInput').val());
							$.blockUI({
								message : 'Start Analysing ...'
							});
							$
									.ajax(
											{
												url : serviceUrl
														+ '/marketAnalysis/searchkeywordcount?keyword='
														+ $(
																'#marketSegmentInput')
																.val(),
												dataType : 'jsonp'
											}).done(function(data) {
										refreshUrl();
									});
						}
					});
	$('#keyDistanceBtn').click(function() {
		$('#tabsBtn2').removeClass("hidden");
		if (geolatLon == false) {
			$('#keyDistanceList').empty();
			$.blockUI({
				message : 'Start Analysing ...'
			});
			getLocation();
			// refreshUrl();
			geolatLon = true;
		}
	});
	$('#tabsBtn1').click(function() {
		$('#table').removeClass("hidden");
		$('#table').addClass("active");
		$('#gmap').removeClass("active");
		$('#gmap').addClass("hidden");
		$('#tableFB').removeClass("active");
		$('#tableFB').addClass("hidden");
	});

	$('#tabsBtnFB').click(function() {
		if (!getFacebooPersonsDone) {
			$.blockUI({
				message : 'Start Analysing ...'
			});
		}
		$('#tableFB').removeClass("hidden");
		$('#tableFB').addClass("active");
		$('#gmap').removeClass("active");
		$('#gmap').addClass("hidden");
		$('#table').removeClass("active");
		$('#table').addClass("hidden");

	});

	$('#tabsBtn2').click(function() {
		$('#gmap').addClass("active");
		$('#gmap').removeClass("hidden");
		$('#table').removeClass("active");
		$('#table').addClass("hidden");
		$('#tableFB').removeClass("active");
		$('#tableFB').addClass("hidden");
	});

	new ShareButton(
			{
				// url: getShareUrl(),
				networks : {
					twitter : {
						url : window.location.href
								+ "&hitBack=true&channel=twitter",
						after : function() {
							$
									.ajax({
										url : serviceUrl
												+ "/marketAnalysis/share?network=twitter&keywordList="
												+ keywords,
										dataType : 'jsonp'
									})
						}
					},
					facebook : {
						url : window.location.href
								+ "&hitBack=true&channel=facebook",
						after : function() {
							$
									.ajax({
										url : serviceUrl
												+ "marketAnalysis/share?network=facebook&keywordList="
												+ keywords,
										dataType : 'jsonp'
									})
						}
					},
					email : {
						url : window.location.href
								+ "&hitBack=true&channel=email",
						after : function() {
							$
									.ajax({
										url : serviceUrl
												+ "/marketAnalysis/share?network=email&keywordList="
												+ keywords,
										dataType : 'jsonp'
									})
						}
					},
					google_plus : {
						url : window.location.href
								+ "&hitBack=true&channel=googlePlus",
						after : function() {
							$
									.ajax({
										url : serviceUrl
												+ "/marketAnalysis/share?network=google_plus&keywordList="
												+ keywords,
										dataType : 'jsonp'
									})
						}
					}
				}
			});

});

function loopStart(i) {

	if (keywords[i] === undefined) {

	} else {
		$('#table').addClass("active");
		$('#table').removeClass("hidden");
		$('#gmap').addClass("hidden");
		$('#tabsBtn2').addClass("hidden");
		geolatLon = false;
		$('#keyDistanceList').empty();

		if (i == keywords.length - 1) {

			$("#marketSegmentInput").val(keywords[i]);
			startProgress(keywords[i], region[i], age[i], gender[i], "yes");

		} else {
			startProgress(keywords[i], region[i], age[i], gender[i], "no");
		}

	}
}

function getLocation(position) {
	if (localStorage.geolatitude && localStorage.geolongitude) {
		var dayDate = new Date();
		if (localStorage.Day == dayDate.getDate()
				&& localStorage.Month == dayDate.getMonth()
				&& localStorage.Year == dayDate.getFullYear()) {
			geolatitude = parseFloat(localStorage.geolatitude);
			geolongitude = parseFloat(localStorage.geolongitude);
			// var keywords = $('#marketSegmentInput').val();
			getPersonsCountByDistance(geolatitude, geolongitude, geoKeyword);
		} else {

			if (navigator.geolocation) {
				navigator.geolocation.getCurrentPosition(showPosition);
				// navigator.geolocation.getCurrentPosition(showfbPosition);
			}

		}

	} else {
		if (navigator.geolocation) {
			navigator.geolocation.getCurrentPosition(showPosition);
			// navigator.geolocation.getCurrentPosition(showfbPosition);
		}
	}
}

function showPosition(position) {
	geolatitude = position.coords.latitude;
	geolongitude = position.coords.longitude;
	localStorage.geolatitude = geolatitude;
	localStorage.geolongitude = geolongitude;
	var dayDate = new Date();
	localStorage.Day = dayDate.getDate();
	localStorage.Month = dayDate.getMonth();
	localStorage.Year = dayDate.getFullYear();
	// var keywords = $('#marketSegmentInput').val();
	getPersonsCountByDistance(geolatitude, geolongitude, geoKeyword);
}

function showfbPosition(geolatitude, geolongitude, distance, keywords) {
	getFacebookLikesLocation(geolatitude, geolongitude, distance, keywords,
			function(res) {
				addPersonsFB(res);
				var locationArray = [];
				var fbId = [];
				var locationName = [];
				res.forEach(function(user) {

					locationArray.push({
						lat : user.latitude,
						lng : user.longitude
					});
					fbId.push(user.postId);
					locationName.push(user.city);

				});

				initMapFacebook(locationArray, fbId, locationName);
				$.unblockUI();
			});

}

function refreshUrl() {

	var keywordsQuery = jQuery.query.get("key");
	var regionQuery = jQuery.query.get("region");
	var ageQuery = jQuery.query.get("age");
	var genderQuery = jQuery.query.get("gender");
	var keywordsInput = $('#marketSegmentInput').val();
	var regionInput = $('#personaDescriptionRegionInput').find(":selected")
			.text()
	var ageInput = $('#personaDescriptionAgeInput').find(":selected").text()
	var genderInput = $('#personaDescriptionGenderInput').find(":selected")
			.text();

	if (keywordsQuery != "") {
		window.location.search = "key=" + keywordsQuery + "|" + keywordsInput
				+ "&region=" + regionQuery + "|" + regionInput + "&age="
				+ ageQuery + "|" + ageInput + "&gender=" + genderQuery + "|"
				+ genderInput;
	} else {
		window.location.search = "key=" + keywordsInput + "&region="
				+ regionInput + "&age=" + ageInput + "&gender=" + genderInput;

	}
}

/*
 * function getShareUrl() { var keywords = $('input[name=searchWords]').val();
 * var shareUrl = "http://www.idea2validate.com?keyword=" + keywords; return
 * shareUrl; }
 */

function getShareUrl() {

	// Currently not possible due to limitations in the sharing plugin
	// var shareUrl = window.location.href + "&timestamp=" + Date.now();
	// location.hash = '&hitBack=true';
	var shareUrl = window.location.href;
	return shareUrl + "&hitBack=true";
}

function getShareImage(service) {
	var img;
	switch (service) {
	case "facebook":
		img = "http://w.sharethis.com/images/facebook_32.png";
		break;
	case "twitter":
		img = "http://w.sharethis.com/images/twitter_32.png";
		break;
	case "pinterest":
		img = "http://w.sharethis.com/images/pinterest_32.png";
		break;
	case "linkedin":
		img = "http://w.sharethis.com/images/linkedin_32.png";
		break;
	case "googleplus":
		img = "http://w.sharethis.com/images/googleplus_32.png";
		break;
	case "email":
		img = "http://w.sharethis.com/images/email_32.png";
		break;
	}
	return img;
}

function refreshShareUrl() {
	var shareUrl = getShareUrl();
	var htmlString = "<span id =\"twitter\" class=\"st_twitter_large\" st_url=\" "
			+ shareUrl
			+ "\" st_title=\"Market Size\"></span> \
										<span id =\"facebook\" class=\"st_facebook_large\" st_url=\" "
			+ shareUrl
			+ "\" st_title=\"Market Size\"></span> \
										<span id =\"linkedin\" class=\"st_linkedin_large\" st_url=\" "
			+ shareUrl
			+ "\" st_title=\"Market Size\"></span> \
										<span id =\"pinterest\" class=\"st_pinterest_large\" st_url=\" "
			+ shareUrl
			+ "\" st_title=\"Market Size\"></span> \
										<span id =\"googleplus\" class=\"st_googleplus_large\" st_url=\" "
			+ shareUrl
			+ "\" st_title=\"Market Size\"></span> \
										<span id =\"email\" class=\"st_email_large\" st_url=\" "
			+ shareUrl + "\" st_title=\"Market Size\"></span>";
	$("#share_this").html(htmlString);

	$("#share_this").find('span').each(function() {
		var img = getShareImage($(this).prop('id'));

		stWidget.addEntry({
			"service" : $(this).prop('id'),
			"element" : this,
			"url" : shareUrl,
			"title" : $(this).prop('title'),
			"type" : "large",
			"text" : $(this).prop('displayText'),
			"image" : img,
			"summary" : "idea 2 validate"
		});
	});

}
// added the regional parameter into the x-axis legend
function startProgress(keywords, region, age, gender, flag) {
	$('#table').addClass("active");
	$('#table').removeClass("hidden");
	$('#gmap').addClass("hidden");

	$('#tableFB').addClass("hidden");
	$('#tableFB').removeClass("active");

	$('#tabsBtn2').addClass("hidden");

	geoKeyword = keywords;
	// var keywords = $('#marketSegmentInput').val();
	var legend = keywords + " / " + region + " / " + age + " / " + gender;
	var preKeywords = $('input[name=searchWords]').val();
	var curKeyWords;
	if ((preKeywords != "") && (preKeywords != " ") && (preKeywords != null)) {
		curKeyWords = preKeywords + "," + keywords;
	} else {
		curKeyWords = keywords;
	}
	curKeyWords = curKeyWords.replace(/\s+/g, '');

	$('input[name=searchWords]').val(curKeyWords);
	refreshShareUrl();

	processCount = (parseInt(processCount) + 1);

	if (processCount > 0) {
		$('#personaDescriptionRegionInput').prop('disabled', false);
		$('#personaDescriptionAgeInput').prop('disabled', false);
		$('#personaDescriptionGenderInput').prop('disabled', false);
	}

	if (keywords) {
		$('#marketSegmentGroup').removeClass('has-error');
		$('#marketSegmentGroup').addClass('has-success');
	} else {
		$('#marketSegmentGroup').removeClass('has-success');
		$('#marketSegmentGroup').addClass('has-error');
		return;
	}

	progressDone = false;

	if (localStorage.entities) {
		var countData = [];
		countData = JSON.parse(localStorage.entities);
		var object = $(countData).filter(function() {
			return this.keyword == keywords;
		}).first();

		if (object !== null) {

			if (object[0] && object[0].keyword) {
				loopCount++;
				loopStart(loopCount);
				progressDone = true;
				var likes = filterLikes(object[0].count, region, age, gender);
				doneProcessing(likes, legend);
				$('#segmentResult').text(keywords);
				localStorageFoundCount = true;
			}

			else {

				localStorageFoundCount = false;
			}

		} else {

			localStorageFoundCount = false;
		}

	}

	if (!localStorageFoundCount) {
		getPageLikeCount(keywords, function(res) {
			var countDetail = {
				"keyword" : keywords,
				"count" : res.count
			};
			if (localStorage.entities) {
				var countData = [];
				countData = JSON.parse(localStorage.entities);
				countData.push(countDetail);
				localStorage.entities = JSON.stringify(countData);

			} else {
				localStorage.entities = [];
				var countData = [];
				countData.push(countDetail)
				localStorage.entities = JSON.stringify(countData);
			}

			progressDone = true;
			var likes = filterLikes(res.count, region, age, gender);
			doneProcessing(likes, legend);
			$('#segmentResult').text(keywords);

		});
	}
	if (flag == "yes") {
		getFacebooPersonsDone = false;
		if (localStorage.tableDataFacebook) {

			var resultDetail = [];
			resultDetail = JSON.parse(localStorage.tableDataFacebook);
			var object = $(resultDetail).filter(function() {
				return this.keyword == keywords;
			}).first();

			if (object !== null) {
				if (object[0] && object[0].keyword) {
					getFacebooPersonsDone = true;
					addPersonsFB(object[0].results);
					$.unblockUI();
					localStorageFacebookResult = true;
				}

				else {

					localStorageFacebookResult = false;
				}

			} else {

				localStorageFacebookResult = false;
			}

		}

		if (!localStorageFacebookResult) {
			getFacebookLikes(keywords, function(res) {
				var resultDetail = {
					"keyword" : keywords,
					"results" : res
				};

				if (localStorage.tableDataFacebook) {
					var facebookResultData = [];
					facebookResultData = JSON
							.parse(localStorage.tableDataFacebook);
					facebookResultData.push(resultDetail);
					localStorage.tableDataFacebook = JSON
							.stringify(facebookResultData);

				} else {
					localStorage.tableDataFacebook = [];
					var facebookResultData = [];
					facebookResultData.push(resultDetail)
					localStorage.tableDataFacebook = JSON
							.stringify(facebookResultData);
				}
				getFacebooPersonsDone = true;
				addPersonsFB(res);
			});
		}

		getPersonsDone = false;
		if (localStorage.tableDataTwitter) {
			var resultDetail = [];
			resultDetail = JSON.parse(localStorage.tableDataTwitter);
			var object = $(resultDetail).filter(function() {
				return this.keyword == keywords;
			}).first();

			if (object !== null) {
				if (object[0] && object[0].keyword) {
					getPersonsDone = true;
					addPersons(object[0].results);
					localStorageTwitterResult = true;
				}

				else {

					localStorageTwitterResult = false;
				}

			} else {

				localStorageTwitterResult = false;
			}

		}

		if (!localStorageTwitterResult) {
			getPersons(keywords, function(res) {
				var resultDetail = {
					"keyword" : keywords,
					"results" : res
				};

				if (localStorage.tableDataTwitter) {
					var TwitterResultData = [];
					TwitterResultData = JSON
							.parse(localStorage.tableDataTwitter);
					TwitterResultData.push(resultDetail);
					localStorage.tableDataTwitter = JSON
							.stringify(TwitterResultData);

				} else {
					localStorage.tableDataTwitter = [];
					var TwitterResultData = [];
					TwitterResultData.push(resultDetail)
					localStorage.tableDataTwitter = JSON
							.stringify(TwitterResultData);
				}
				getPersonsDone = true;
				addPersons(res);
				$.unblockUI();
			});
		}

	}

	$('#processBtn').prop('disabled', true);
	$('#processBarContainer').toggle(true);
	startFakeProcess(1, 5, setProgressDisplayToDone);

	$('#arrowLeft').fadeOut(1000);
	$('#arrowRight').fadeOut(1000);
}

function doneProcessing(likeCount, keywords) {

	if (initResults) {
		resultInitTransitions();
		initResults = false;
		setTimeout(doneProcessing(likeCount, keywords), 1500);
		return;
	}

	setTimeout(function() {
		addNewDataSeries({
			name : keywords,
			y : calculateMarketSize(likeCount),
			likes : likeCount
		});
	}, 500);

	$('#headerInput').html('Change Variables And Process To Compare Markets');
}
// Update regional factors - STEVE
function filterLikes(likes, region, age, gender) {
	var regionFactor;
	var ageFactor;
	var genderFactor;

	switch (region) {
	case "All":
		regionFactor = 1;
		break;
	case "Asia Pacific":
		regionFactor = 0.288;
		break;
	case "Europe":
		regionFactor = 0.241;
		break;
	case "North America":
		regionFactor = 0.172;
		break;
	case "Rest of World":
		regionFactor = 0.299;
		break;
	}
	// Age filter - STEVE
	switch (age) {
	case "All":
		ageFactor = 1;
		break;
	case "16-24":
		ageFactor = 0.25;
		break;
	case "25-34":
		ageFactor = 0.29;
		break;
	case "35-44":
		ageFactor = 0.22;
		break;
	case "45-54":
		ageFactor = 0.15;
		break;
	case "55-65":
		ageFactor = 0.09;
		break;
	}
	// Update gender filters STEVE
	switch (gender) {
	case "All":
		genderFactor = 1;
		break;
	case "Female":
		genderFactor = 0.53;
		break;
	case "Male":
		genderFactor = 0.47;
		break;
	}

	// Update filtered Likes calculation and integer parsing STEVE
	var filteredLikes = likes ? likes * regionFactor * ageFactor * genderFactor
			: 0;
	return parseInt(filteredLikes, 10);
}

function calculateMarketSize(likes) {
	var marketSize = likes ? likes * marketSizeFaktorPerPotentialUser : 0;

	return parseInt(marketSize, 10);
}

function getPageLikeCount(keywords, success) {
	$.ajax({
		url : serviceUrl + '/marketAnalysis/size?keywords=' + keywords,
		dataType : 'jsonp',
		success : success
	}).done(function() {
		loopCount++;
		loopStart(loopCount);
	});
}

function getPersons(keywords, success) {
	var count = 10;
	var sort = 2;

	$.ajax({
		url : serviceUrl + '/marketAnalysis/persons?keywords=' + keywords
				+ '&count=' + count + '&sort=' + sort,
		dataType : 'jsonp',
		success : success
	});
}

function getFacebookLikes(keywords, success) {
	var count = 11;
	var sort = 2;
	$.ajax({
		url : serviceUrl + '/marketAnalysis/pagesComments?keywords=' + keywords
				+ '&count=' + count + '&sort=' + sort,
		dataType : 'jsonp',
		success : success
	});
}

function getFacebookLikesLocation(geolatitude, geolongitude, distance,
		keywords, success) {
	var count = 10;
	var sort = 2;
	$
			.ajax({
				url : serviceUrl + '/marketAnalysis/fbLocation?latitude='
						+ geolatitude + '&longitude=' + geolongitude
						+ '&distance=' + distance + '&count=' + count
						+ '&sort=' + sort + '&keywords=' + keywords,
				dataType : 'jsonp',
				success : success
			});
}
function searchCount(keyword) {
	alert(keyword);
	$.blockUI({
		message : 'Start Analysing ...'
	});
	$.ajax(
			{
				url : serviceUrl
						+ '/marketAnalysis/searchkeywordcount?keyword='
						+ keyword,
				dataType : 'jsonp'
			}).done(function(data) {
		alert(data);
	}).fail(function() {

		alert("Service unavailble");
	});
}

function getPersonsCountByDistance(geolatitude, geolongitude, keywords) {
	var count1 = 0, count2 = 0, count3 = 0, count4 = 0, count5 = 0, countun = 0;
	var fbLocData;
	var count = 10;
	var distance = 14;
	var sort = 2;
	$.blockUI({
		message : 'Start Analysing ...'
	});
	$
			.ajax(
					{
						url : serviceUrl
								+ '/marketAnalysis/fbLocation?latitude='
								+ geolatitude + '&longitude=' + geolongitude
								+ '&distance=' + distance + '&count=' + count
								+ '&sort=' + sort + '&keywords=' + keywords,
						dataType : 'jsonp'
					})
			.done(
					function(data) {
						fbLocData = data;
						addPersonsFB(data);
						data.forEach(function(user) {
							if (user.distance == 1) {
								count1 = count1 + 1;
							} else if (user.distance == 10) {
								count2 = count2 + 1;
							} else if (user.distance == 100) {
								count3 = count3 + 1;
							} else if (user.distance == 1000) {
								count4 = count4 + 1;
							} else if (user.distance == 10000) {
								count5 = count5 + 1;
							} else if (user.distance == 10001) {
								countun = countun + 1;
							}
						});

						$
								.ajax(
										{
											url : serviceUrl
													+ '/marketAnalysis/personsCount?latitude='
													+ geolatitude
													+ '&longitude='
													+ geolongitude + '&sort='
													+ sort + '&keywords='
													+ keywords,
											dataType : 'jsonp'
										})
								.done(
										function(data) {
											if (data.byDistanceOne != null) {
												count1 = count1
														+ data.byDistanceOne.count;
												$('#keyDistanceList')
														.append(
																'<li id="oneKM"><input style="background: #fff; width:100%; border: none; margin: 4px 0  " type="button" value="1km - '
																		+ count1
																		+ '"/></li>');
											}
											if (data.byDistanceTen != null) {
												count2 = count2
														+ data.byDistanceTen.count;
												$('#keyDistanceList')
														.append(
																'<li id="tenKM"><input style="background: #fff; width:100%; border: none; margin: 4px 0  " type="button" value="10km - '
																		+ count2
																		+ '"/></li>');
											}
											if (data.byDistanceHundred != null) {
												count3 = count3
														+ data.byDistanceHundred.count;
												$('#keyDistanceList')
														.append(
																'<li id="hundradKM"><input style="background: #fff; width:100%; border: none; margin: 4px 0  " type="button" value="100km - '
																		+ count3
																		+ '"/></li>');
											}

											if (data.byDistanceThousand != null) {
												count4 = count4
														+ data.byDistanceThousand.count;
												$('#keyDistanceList')
														.append(
																'<li id="thousandKM"><input style="background: #fff; width:100%; border: none; margin: 4px 0   " type="button" value="1000km - '
																		+ count4
																		+ '"/></li>');
											}
											if (data.byDistanceTenThousand != null) {
												count5 = count5
														+ data.byDistanceTenThousand.count;
												$('#keyDistanceList')
														.append(
																'<li id="tenthousandKM"><input style="background: #fff; width:100% ;border: none; margin: 4px 0 " type="button" value="10000km - '
																		+ count5
																		+ '"/></li>');
											}
											if (data.unknownUsers != null) {
												countun = countun
														+ data.unknownUsers.count;
												$('#keyDistanceList')
														.append(
																'<li id="unkownKM"><input style="background: #fff; width:100% ; border: none; margin: 4px 0 " type="button" value="Unknown - '
																		+ countun
																		+ '"/></li>');
											}

											$('#oneKM')
													.click(
															function() {
																var locationArray = [];
																var tweetId = [];
																var locationName = [];
																var userCountry = [];
																var profileName = [];
																var profilePicture = [];
																addPersonsLoc(data.byDistanceOne.knownUsers);
																for (var i = 0; i < data.byDistanceOne.knownUsers.length; i++) {
																	locationArray
																			.push({
																				lat : data.byDistanceOne.knownUsers[i].latitude,
																				lng : data.byDistanceOne.knownUsers[i].longitude
																			});
																	tweetId
																			.push(data.byDistanceOne.knownUsers[i].tweetId);
																	locationName
																			.push(data.byDistanceOne.knownUsers[i].locationName);
																	profileName
																			.push(data.byDistanceOne.knownUsers[i].profileName);
																	profilePicture
																			.push(data.byDistanceOne.knownUsers[i].proifleImageUrl);
																}
																$('#gmap')
																		.addClass(
																				"active");
																$('#gmap')
																		.removeClass(
																				"hidden");
																$('#table')
																		.removeClass(
																				"active");
																$('#table')
																		.addClass(
																				"hidden");
																$('#tableFB')
																		.removeClass(
																				"active");
																$('#tableFB')
																		.addClass(
																				"hidden");
																$
																		.blockUI({
																			message : 'Please Wait ...'
																		});

																addPersonsFBLoC(
																		fbLocData,
																		1);
																fbLocData
																		.forEach(function(
																				user) {
																			if (user.distance == 1) {
																				locationArray
																						.push({
																							lat : user.latitude,
																							lng : user.longitude
																						});
																				userCountry
																						.push(user.country);

																				tweetId
																						.push("FB"
																								+ user.postId);
																				locationName
																						.push(user.city);
																				profileName
																						.push(user.userName);
																				profilePicture
																						.push(user.picture);
																			}
																		});

																$.unblockUI();
																initMap(
																		locationArray,
																		tweetId,
																		locationName,
																		userCountry,
																		profileName,
																		profilePicture);

															});
											$('#tenKM')
													.click(
															function() {

																var tenLength = data.byDistanceTen.knownUsers.length;
																var locationArray = [];
																var tweetId = [];
																var locationName = [];
																var userCountry = [];
																var profileName = [];
																var profilePicture = [];
																addPersonsLoc(data.byDistanceTen.knownUsers);
																for (var i = 0; i < tenLength; i++) {
																	locationArray
																			.push({
																				lat : data.byDistanceTen.knownUsers[i].latitude,
																				lng : data.byDistanceTen.knownUsers[i].longitude
																			});
																	tweetId
																			.push(data.byDistanceTen.knownUsers[i].tweetId);
																	locationName
																			.push(data.byDistanceTen.knownUsers[i].locationName);
																	profileName
																			.push(data.byDistanceTen.knownUsers[i].profileName);
																	profilePicture
																			.push(data.byDistanceTen.knownUsers[i].proifleImageUrl);
																}
																$('#gmap')
																		.addClass(
																				"active");
																$('#gmap')
																		.removeClass(
																				"hidden");
																$('#table')
																		.removeClass(
																				"active");
																$('#table')
																		.addClass(
																				"hidden");
																$('#tableFB')
																		.removeClass(
																				"active");
																$('#tableFB')
																		.addClass(
																				"hidden");
																$
																		.blockUI({
																			message : 'Please Wait ...'
																		});
																addPersonsFBLoC(
																		fbLocData,
																		10);
																fbLocData
																		.forEach(function(
																				user) {
																			if (user.distance == 10) {
																				locationArray
																						.push({
																							lat : user.latitude,
																							lng : user.longitude
																						});
																				userCountry
																						.push(user.country);

																				tweetId
																						.push("FB"
																								+ user.postId);
																				locationName
																						.push(user.city);
																				profileName
																						.push(user.userName);
																				profilePicture
																						.push(user.picture);
																			}
																		});

																$.unblockUI();
																initMap(
																		locationArray,
																		tweetId,
																		locationName,
																		userCountry,
																		profileName,
																		profilePicture);

															});
											$('#hundradKM')
													.click(
															function() {

																var tenLength = data.byDistanceHundred.knownUsers.length;
																var locationArray = [];
																var tweetId = [];
																var locationName = [];
																var userCountry = [];
																var profileName = [];
																var profilePicture = [];
																addPersonsLoc(data.byDistanceHundred.knownUsers);
																for (var i = 0; i < tenLength; i++) {
																	locationArray
																			.push({
																				lat : data.byDistanceHundred.knownUsers[i].latitude,
																				lng : data.byDistanceHundred.knownUsers[i].longitude
																			});
																	tweetId
																			.push(data.byDistanceHundred.knownUsers[i].tweetId);
																	locationName
																			.push(data.byDistanceHundred.knownUsers[i].locationName);
																	profileName
																			.push(data.byDistanceHundred.knownUsers[i].profileName);
																	profilePicture
																			.push(data.byDistanceHundred.knownUsers[i].proifleImageUrl);
																}
																$('#gmap')
																		.addClass(
																				"active");
																$('#gmap')
																		.removeClass(
																				"hidden");
																$('#table')
																		.removeClass(
																				"active");
																$('#table')
																		.addClass(
																				"hidden");
																$('#tableFB')
																		.removeClass(
																				"active");
																$('#tableFB')
																		.addClass(
																				"hidden");
																$
																		.blockUI({
																			message : 'Please Wait ...'
																		});
																addPersonsFBLoC(
																		fbLocData,
																		100);
																fbLocData
																		.forEach(function(
																				user) {
																			if (user.distance == 100) {
																				locationArray
																						.push({
																							lat : user.latitude,
																							lng : user.longitude
																						});
																				userCountry
																						.push(user.country);

																				tweetId
																						.push("FB"
																								+ user.postId);
																				locationName
																						.push(user.city);
																				profileName
																						.push(user.userName);
																				profilePicture
																						.push(user.picture);
																			}
																		});

																$.unblockUI();
																initMap(
																		locationArray,
																		tweetId,
																		locationName,
																		userCountry,
																		profileName,
																		profilePicture);

															});
											$('#thousandKM')
													.click(
															function() {

																var tenLength = data.byDistanceThousand.knownUsers.length;
																var locationArray = [];
																var tweetId = [];
																var locationName = [];
																var userCountry = [];
																var profileName = [];
																var profilePicture = [];
																addPersonsLoc(data.byDistanceThousand.knownUsers);
																for (var i = 0; i < tenLength; i++) {

																	locationArray
																			.push({
																				lat : data.byDistanceThousand.knownUsers[i].latitude,
																				lng : data.byDistanceThousand.knownUsers[i].longitude
																			});
																	tweetId
																			.push(data.byDistanceThousand.knownUsers[i].tweetId);
																	locationName
																			.push(data.byDistanceThousand.knownUsers[i].locationName);
																	profileName
																			.push(data.byDistanceThousand.knownUsers[i].profileName);
																	profilePicture
																			.push(data.byDistanceThousand.knownUsers[i].proifleImageUrl);
																}
																$('#gmap')
																		.addClass(
																				"active");
																$('#gmap')
																		.removeClass(
																				"hidden");
																$('#table')
																		.removeClass(
																				"active");
																$('#table')
																		.addClass(
																				"hidden");
																$('#tableFB')
																		.removeClass(
																				"active");
																$('#tableFB')
																		.addClass(
																				"hidden");
																$
																		.blockUI({
																			message : 'Please Wait ...'
																		});
																addPersonsFBLoC(
																		fbLocData,
																		1000);
																fbLocData
																		.forEach(function(
																				user) {
																			if (user.distance == 1000) {
																				locationArray
																						.push({
																							lat : user.latitude,
																							lng : user.longitude
																						});
																				userCountry
																						.push(user.country);

																				tweetId
																						.push("FB"
																								+ user.postId);
																				locationName
																						.push(user.city);
																				profileName
																						.push(user.userName);
																				profilePicture
																						.push(user.picture);
																			}
																		});

																$.unblockUI();
																initMap(
																		locationArray,
																		tweetId,
																		locationName,
																		userCountry,
																		profileName,
																		profilePicture);
															});
											$('#tenthousandKM')
													.click(
															function() {

																var locationArray = [];
																var tweetId = [];
																var locationName = [];
																var userCountry = [];
																var profileName = [];
																var profilePicture = [];
																addPersonsLoc(data.byDistanceTenThousand.knownUsers);
																for (var i = 0; i < data.byDistanceTenThousand.knownUsers.length; i++) {

																	locationArray
																			.push({
																				lat : data.byDistanceTenThousand.knownUsers[i].latitude,
																				lng : data.byDistanceTenThousand.knownUsers[i].longitude
																			});
																	tweetId
																			.push(data.byDistanceTenThousand.knownUsers[i].tweetId);
																	locationName
																			.push(data.byDistanceTenThousand.knownUsers[i].locationName);
																	profileName
																			.push(data.byDistanceTenThousand.knownUsers[i].profileName);
																	profilePicture
																			.push(data.byDistanceTenThousand.knownUsers[i].proifleImageUrl);
																}
																$('#gmap')
																		.addClass(
																				"active");
																$('#gmap')
																		.removeClass(
																				"hidden");
																$('#table')
																		.removeClass(
																				"active");
																$('#table')
																		.addClass(
																				"hidden");
																$('#tableFB')
																		.removeClass(
																				"active");
																$('#tableFB')
																		.addClass(
																				"hidden");
																$
																		.blockUI({
																			message : 'Please Wait ...'
																		});
																addPersonsFBLoC(
																		fbLocData,
																		10000);
																fbLocData
																		.forEach(function(
																				user) {
																			if (user.distance == 10000) {
																				locationArray
																						.push({
																							lat : user.latitude,
																							lng : user.longitude
																						});
																				userCountry
																						.push(user.country);

																				tweetId
																						.push("FB"
																								+ user.postId);
																				locationName
																						.push(user.city);
																				profileName
																						.push(user.userName);
																				profilePicture
																						.push(user.picture);
																			}
																		});

																$.unblockUI();
																initMap(
																		locationArray,
																		tweetId,
																		locationName,
																		userCountry,
																		profileName,
																		profilePicture);
															});
											$('#unkownKM')
													.click(
															function() {

																var locationArray = [];
																var tweetId = [];
																var locationName = [];
																var userCountry = [];
																var profileName = [];
																var profilePicture = [];
																addPersonsLoc(data.unknownUsers.knownUsers);
																for (var i = 0; i < data.unknownUsers.length; i++) {
																	locationArray
																			.push({
																				lat : data.unknownUsers.knownUsers[i].latitude,
																				lng : data.unknownUsers.knownUsers[i].longitude
																			});
																	tweetId
																			.push(data.unknownUsers.knownUsers[i].tweetId);
																	locationName
																			.push(data.unknownUsers.knownUsers[i].locationName);
																	profileName
																			.push(data.unknownUsers.knownUsers[i].profileName);
																	profilePicture
																			.push(data.unknownUsers.knownUsers[i].proifleImageUrl);
																}
																$('#gmap')
																		.addClass(
																				"active");
																$('#gmap')
																		.removeClass(
																				"hidden");
																$('#table')
																		.removeClass(
																				"active");
																$('#table')
																		.addClass(
																				"hidden");

																addPersonsFBLoC(
																		fbLocData,
																		10001);
																fbLocData
																		.forEach(function(
																				user) {
																			if (user.distance == 10001) {
																				locationArray
																						.push({
																							lat : user.latitude,
																							lng : user.longitude
																						});
																				userCountry
																						.push(user.country);

																				tweetId
																						.push("FB"
																								+ user.postId);
																				locationName
																						.push(user.city);
																				profileName
																						.push(user.userName);
																				profilePicture
																						.push(user.picture);
																			}
																		});

																$.unblockUI();
																initMap(
																		locationArray,
																		tweetId,
																		locationName,
																		userCountry,
																		profileName,
																		profilePicture);

															});
											$.unblockUI();
										})
								.fail(
										function() {
											$.unblockUI();
											alert("Twitter Location Service is unavailble");
										});

					}).fail(function() {
				$.unblockUI();
				alert("Facebook Location Service is unavailble");
			});
}

// Column array colour set blue if in the corridor and red if outside -STEVE
function addNewDataSeries(data) {
	data.color = '#A9FF96';
	var newDataArray = [ data ];
	for (var i = 0; i < chartData.length; i++) {
		var series = chartData[i];
		if (series.y < 5000000 || series.y > 100000000) {
			series.color = 'red';
		} else {
			series.color = '#7CB5EC';
		}
		newDataArray.push(series);
	}
	chartData = newDataArray;

	printMarketSizeChart(chartData);

	setTimeout(function() {
		var chart = $("#marketSizeChart").highcharts();
		chart.series[0].data[0].setState('hover');
		chart.tooltip.refresh(chart.series[0].data[0]);
	}, 1500);
}

function setProgressDisplayToDone() {
	$('#processBtn').prop('disabled', false);
	$('#processBarContainer').toggle(false);
	$('#processBar').width('0%');
}

function resultInitTransitions() {
	setTimeout(function() {
		$('#inputPanel').toggleClass('col-sm-6 col-sm-5');

		setTimeout(displayResults, 600);
	}, 500);
}

function displayResults() {
	$('#resultPanel').fadeIn(1000);
}

function startFakeProcess(counter, steps, doneCallback) {
	if (counter > steps || progressDone) {
		doneCallback();
	} else {
		setTimeout(function() {
			if (!progressDone) {
				var step = (100 / steps) * counter;
				$('#processBar').width(step + '%');
			}
			startFakeProcess(counter + 1, steps, doneCallback);
		}, 200);
	}
}

function printMarketSizeChart(data) {
	$('#marketSizeChart')
			.highcharts(
					{
						chart : {
							type : 'column'
						},
						title : {
							text : '<span style="font-size: 15px;color: black;">Indicative Market Size in US$ (Only FB-Users & Referal income)</span>'

						},
						credits : false,
						legend : {
							enabled : false
						},
						xAxis : {
							type : 'category',
							labels : {
								rotation : -45,
								style : {
									fontSize : '13px',
									fontFamily : 'Verdana, sans-serif'
								}
							}
						},
						yAxis : {
							min : 0,
							title : {
								text : '<span style="font-size: 11px;color: orange;">StartUp Corridor 5-100M | Competition Intensity</span>'
							},
							// Creation of startup corridor Lines for the
							// visulization
							// 04/05/2015
							plotLines : [
									{
										value : 5000000,
										color : 'orange',
										dashStyle : 'dot',
										width : 2,
										label : {
											useHTML : true,
											text : '<span style="font-size: 8px;font-style: italic;color: black;">if < 5Mio$,increase market</span>'
										},
										zIndex : 5
									},
									{
										value : 100000000,
										color : 'orange',
										dashStyle : 'dot',
										width : 2,
										label : {
											useHTML : true,
											text : '<span style="font-size: 8px;font-style: italic;color: black;">If >100Mio$, segment market</span>'
										},
										zIndex : 5
									} ]
						},
						tooltip : {
							pointFormat : 'Market Size: <b>{point.y}</b> Facebook Likes: <b>{point.likes}</b>'
						},
						plotOptions : {
							series : {
								borderWidth : 0,
								pointPadding : 0.2,
								dataLabels : {
									enabled : true,
									format : '{point.y:,.0f}'
								}
							}
						},
						series : [ {
							data : data,
							point : {
								events : {
									click : function() {
										$.blockUI({
											message : 'Please Wait ...'
										});
										$('#keyDistanceList').empty();
										// $('#keyUserTable').empty();
										$('#map').empty();
										var label = this.options.name;

										var keywords = label.split("/")[0]
												.trim();
										var region = label.split("/")[1].trim();
										geolatLon = false;
										geoKeyword = keywords;
										var bothDone = false;
										getFacebookLikes(keywords,
												function(res) {
													addPersonsFB(res);
													if (bothDone) {
														$.unblockUI();
													} else {
														bothDone = true;
													}
												});

										getPersons(keywords, function(res) {
											addPersons(res);
											if (bothDone) {
												$.unblockUI();
											} else {
												bothDone = true;
											}

										});

										/*
										 * $.blockUI({message: 'Please Wait
										 * ...'});
										 * getPersonsCountByDistance(geolatitude,
										 * geolongitude, keywords);
										 * $.unblockUI();
										 */
										/*
										 * getPageLikeCount(keywords, function
										 * (res) { progressDone = true; var
										 * likes = filterLikes(res.count);
										 * doneProcessing(likes, legend);
										 * $('#segmentResult').text(keywords);
										 * $.unblockUI(); });
										 * 
										 * getPersons(function(res){
										 * getPersonsDone = true;
										 * addPersons(res); }, keywords,
										 * region);
										 */
									}
								}
							}
						} ]
					});
}

function initMap(latArray, tweetId, userLocation, userCountry, profileName,
		profilePicture) {

	// alert(userName +"----"+ userLocation);
	map = new google.maps.Map(document.getElementById('map'), {
		center : {
			lat : geolatitude,
			lng : geolongitude
		},
		zoom : 1
	});

	for (var index = 0; index < latArray.length; index++) {
		if (tweetId[index].indexOf("FB") != 0) {
			marker = new google.maps.Marker({
				position : latArray[index],
				map : map,
				icon : 'images/map-marker24t.png',
				title : userLocation[index]
			});

			var infowindow = new google.maps.InfoWindow();

			marker.html = '<div> <a target="_blank" href="https://twitter.com/statuses/'
					+ tweetId[index] + '">' + profileName[index] + '<br>'
					// + "<img width='80' src="
					// + profilePicture[index]
					// + ">"
					+ '</div>';
			google.maps.event.addListener(marker, 'click', function() {
				infowindow.setContent(this.html);
				infowindow.open(map, this);
			});
		} else {
			tweetId[index] = tweetId[index].replace("FB", "");
			marker = new google.maps.Marker({
				position : latArray[index],
				map : map,
				icon : 'images/map-marker24.png',
				title : userLocation[index] + ',' + userCountry[index]
			});

			var infowindow = new google.maps.InfoWindow();

			marker.html = '<a target="_blank" href="https://facebook.com/'
					+ tweetId[index] + '">' + profileName[index] + '<br>'
					// + "<img width='80' src=" + profilePicture[index] + ">"
					+ '</div>';

			google.maps.event.addListener(marker, 'click', function() {
				infowindow.setContent(this.html);
				infowindow.open(map, this);
			});

		}

	}
}

function initMapFacebook(latArray, commentId, userLocation, userCountry) {

	// alert(userName +"----"+ userLocation);
	map = new google.maps.Map(document.getElementById('map'), {
		center : {
			lat : geolatitude,
			lng : geolongitude
		},
		zoom : 1
	});

	for (var index = 0; index < latArray.length; index++) {
		marker = new google.maps.Marker({
			position : latArray[index],
			map : map,
			icon : 'images/map-marker24.png',
			title : userLocation[index] + ',' + userCountry[index]
		});

		var infowindow = new google.maps.InfoWindow();

		marker.html = '<a target="_blank" href="https://facebook.com/'
				+ commentId[index] + '">Show fb Post</div>';

		google.maps.event.addListener(marker, 'click', function() {
			infowindow.setContent(this.html);
			infowindow.open(map, this);
		});
	}
}

function addPersons(res) {
	$('#keyUserTable').find('tr:gt(0)').remove();
	// $('#keyUserTable').empty();
	res
			.forEach(function(user) {
				var userRow = '<tr>';
				userRow += wrapTd('<img height="38px" width="38px" src="'
						+ user.proifleImageUrl + '"></img>');
				userRow += wrapTd(user.followerCount);
				userRow += wrapTd('<a target="_blank" href="https://twitter.com/'
						+ user.screenName + '">' + user.screenName + '</a>');
				userRow += wrapTd(user.retweets);
				userRow += wrapTd('<a target="_blank" href="https://twitter.com/statuses/'
						+ user.tweetId + '">Show Tweet</a>');
				userRow += '</tr>';
				// $('#keyUserTable tr:last').after(userRow);
				$('#keyUserTable tbody').append(userRow);
			});

	console.log(res);
}

function wrapTd(value) {
	return '<td>' + value + '</td>';
}

function addPersonsFB(res) {
	var oCounter = 0;
	$('#keyUserTableFB').find('tr:gt(0)').remove();
	// $('#keyUserTable').empty();
	res.forEach(function(user) {
		if (oCounter <= 10) {
			oCounter = oCounter + 1;
			// var pos = user.picture.indexOf("https");
			// var res = user.picture.slice(pos, -3);
			var pos = user.postId.indexOf("_");
			var userPageLink = user.postId.slice(0, pos);
			var userRow = '<tr>';
			var oDummyurl = "";
			userRow += wrapTd('<img  height="38px" width="38px" src="'
					+ user.picture + '"></img>');
			userRow += wrapTd(user.commentsCount);
			// user.userName = "Backend in Process"
			// userRow += wrapTd(user.userName);
			userRow += wrapTd('<a target="_blank" href="https://facebook.com/'
					+ userPageLink + '">' + user.userName + '</a>');
			userRow += wrapTd(user.likesCount);
			userRow += wrapTd('<a target="_blank" href="https://facebook.com/'
					+ user.postId + '">Show Post</a>');
			// userRow += wrapTd('<button type="button"
			// onclick="">Detail</button>');
			userRow += '</tr>';
			$('#keyUserTableFB tbody').append(userRow);

		}
	});

	console.log(res);
}

function addPersonsFBLoC(res, distance) {
	var oCounter = 0;
	$('#keyUserTableFB').find('tr:gt(0)').remove();
	// $('#keyUserTable').empty();
	res
			.forEach(function(user) {
				if (user.distance == distance) {
					if (oCounter < 5) {
						oCounter = oCounter + 1;
						// var pos = user.picture.indexOf("https");
						// var res = user.picture.slice(pos, -3);
						var userRow = '<tr>';
						var oDummyurl = "";
						userRow += wrapTd('<img  height="38px" width="38px" src="'
								+ user.picture + '"></img>');
						userRow += wrapTd(user.commentsCount);
						// user.userName = "Backend in Process"
						userRow += wrapTd(user.userName);
						userRow += wrapTd(user.likesCount);
						userRow += wrapTd('<a target="_blank" href="https://facebook.com/'
								+ user.postId + '">Show Post</a>');
						// userRow += wrapTd('<button type="button"
						// onclick="">Detail</button>');
						userRow += '</tr>';
						$('#keyUserTableFB tbody').append(userRow);
					}
				}
			});

	console.log(res);
}

function addPersonsLoc(res) {
	$('#keyUserTable').find('tr:gt(0)').remove();
	// $('#keyUserTable').empty();
	res
			.forEach(function(user) {
				var userRow = '<tr>';
				userRow += wrapTd('<img height="38px" width="38px" src="'
						+ user.proifleImageUrl + '"></img>');
				userRow += wrapTd(user.followerCount);
				userRow += wrapTd('<a target="_blank" href="https://twitter.com/'
						+ user.screenName + '">' + user.screenName + '</a>');
				userRow += wrapTd(user.retweets);
				userRow += wrapTd('<a target="_blank" href="https://twitter.com/statuses/'
						+ user.tweetId + '">Show Tweet</a>');
				userRow += '</tr>';
				// $('#keyUserTable tr:last').after(userRow);
				$('#keyUserTable tbody').append(userRow);
			});

	console.log(res);
}
