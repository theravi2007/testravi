package de.i2v.ws.service;

import java.util.List;

public interface IShare {

    // Share getLinkByShareApp(String applicationName, String shareID) throws Exception;

    boolean saveSocialKeyShare(String networkName, String url, List<String> keys) throws Exception;

}
