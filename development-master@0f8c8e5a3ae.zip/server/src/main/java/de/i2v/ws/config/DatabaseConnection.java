package de.i2v.ws.config;

import java.net.URI;
import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import org.postgresql.Driver;


public class DatabaseConnection {

    public static Connection getConnection() throws URISyntaxException, SQLException, ClassNotFoundException {
        Class.forName("org.postgresql.Driver");
        URI dbUri = new URI(
                "postgres://vkuqyzlcwsghje:GA_0MbW-M9dcHAYZ-ivxwDg2Af@ec2-54-204-20-164.compute-1.amazonaws.com:5432/d6rvl27hfv14d");

        String username = dbUri.getUserInfo().split(":")[0];
        String password = dbUri.getUserInfo().split(":")[1];
        String dbUrl = "jdbc:postgresql://" + dbUri.getHost() + dbUri.getPath()
                + "?ssl=true&sslfactory=org.postgresql.ssl.NonValidatingFactory";
        return DriverManager.getConnection(dbUrl, username, password);
    }
}
