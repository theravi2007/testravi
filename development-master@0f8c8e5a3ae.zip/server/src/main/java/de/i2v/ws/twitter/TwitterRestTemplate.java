package de.i2v.ws.twitter;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.*;
import org.springframework.http.client.ClientHttpRequest;
import org.springframework.stereotype.Repository;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.*;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Base64;

@Repository
public class TwitterRestTemplate extends RestTemplate {

	private static String twitterOauthUrl = "https://api.twitter.com/oauth2/token";
	private static String twitterUrl = "https://api.twitter.com";

	private static String consumerKey = "nnWjUe2ZRCzhd4UJ4dINOAjRG";
	private static String consumerSecret = "vanqaPVH9D00GkXfKBU0kQrDM2Yi6PbB16shL2TkWkIHcQwZrq";

	private String accessToken;

	@Override
	protected <T> T doExecute(URI url, HttpMethod method, RequestCallback requestCallback,
                              ResponseExtractor<T> responseExtractor) throws RestClientException {

		synchronized (this) {
			if (accessToken == null) {
				updateAccesToken();
			}
		}

		try {
			return super.doExecute(buildUri(url), method, new RequestCallbackDecorator(requestCallback),
					responseExtractor);
		} catch (HttpClientErrorException e) {
			if (isExpiredSession(e)) {
				updateAccesToken();
				return doExecute(url, method, requestCallback, responseExtractor);
			} else {
				throw e;
			}
		}
	}

	private class RequestCallbackDecorator implements RequestCallback {

		private RequestCallback delegate;

		RequestCallbackDecorator(RequestCallback delegate) {
			this.delegate = delegate;
		}

		@Override
		public void doWithRequest(ClientHttpRequest request) throws IOException {
			HttpHeaders headers = request.getHeaders();
			headers.set("Authorization", "Bearer " + accessToken);
			headers.set("Host", "api.twitter.com");
			headers.set("User-Agent", "Idea2Validate Tweeter");
			delegate.doWithRequest(request);
		}

	}

	private boolean isExpiredSession(HttpClientErrorException e) {
		return e.getStatusCode() == HttpStatus.UNAUTHORIZED
				&& e.getResponseBodyAsString().contains("Invalid or expired token");
	}

	private URI buildUri(URI uri) throws RestClientException {

		String newUrl = twitterUrl + uri.toString();

		try {
			return uri = new URI(newUrl);
		} catch (URISyntaxException e) {
			throw new RestClientException("Couldn't build new URI " + newUrl, e);
		}
	}

	public void updateAccesToken() {
		RestTemplate template = new RestTemplate();
		MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();

		headers.set("Authorization", "Basic " + getAppAuthorization());
		headers.set("Content-type", "application/x-www-form-urlencoded;charset=UTF-8");

		HttpEntity<String> entity = new HttpEntity<String>("grant_type=client_credentials", headers);

		ResponseEntity<String> response = template.exchange(twitterOauthUrl, HttpMethod.POST, entity, String.class);
		ObjectMapper mapper = new ObjectMapper();
		try {
			accessToken = mapper.readTree(response.getBody()).get("access_token").asText();
		} catch (IOException e) {
			throw new RuntimeException("Failed to update Twitter access token", e);
		}
	}

	private String getAppAuthorization() {
		String authorizationKey = consumerKey + ":" + consumerSecret;
		return base64Encode(authorizationKey);
	}

	private String base64Encode(String s) {
		return Base64.getEncoder().encodeToString(s.getBytes());
	}

}