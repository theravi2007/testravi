package de.i2v.ws.google;

import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RequestCallback;
import org.springframework.web.client.ResponseExtractor;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.net.URISyntaxException;

/**
 * The Class GoogleRestTemplate.
 */
@Repository
public class GoogleRestTemplate extends RestTemplate {

    /** The google url. */
    private static String googleUrl = "https://maps.googleapis.com/maps/api";

    /** The secret key. */
    private static String secretKey = "AIzaSyDchALhVmWTOCmvoYThl6tkKkAxJdyO87A";

    /*
     * (non-Javadoc)
     * 
     * @see org.springframework.web.client.RestTemplate#doExecute(java.net.URI, org.springframework.http.HttpMethod,
     * org.springframework.web.client.RequestCallback, org.springframework.web.client.ResponseExtractor)
     */
    @Override
    protected <T> T doExecute(URI url, HttpMethod method, RequestCallback requestCallback,
                              ResponseExtractor<T> responseExtractor) throws RestClientException {
        url = buildUri(url);
        return super.doExecute(url, method, requestCallback, responseExtractor);

    }

    /**
     * Builds the uri.
     * 
     * @param uri the uri
     * @return the uri
     */
    private URI buildUri(URI uri) {
        String newUrl = googleUrl + uri.toString() + "&key=" + secretKey;

        try {
            return uri = new URI(newUrl);
        } catch (URISyntaxException e) {
            throw new RestClientException("Couldn't build new URI " + newUrl, e);
        }
    }
}
