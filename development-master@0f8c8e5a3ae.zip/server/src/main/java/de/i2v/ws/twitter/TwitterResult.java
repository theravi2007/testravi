package de.i2v.ws.twitter;

public class TwitterResult implements Comparable<TwitterResult> {

    public String tweetId;
    public long retweets;
    public String profileName;
    public long followerCount;
    public String screenName;
    public String proifleImageUrl;
    public String locationName;;
    public double latitude;
    public double longitude;
    public int Sort;
    public long weight;
    
    public int getSort() {
		return Sort;
	}

	public void setSort(int Sort) {
		this.Sort = Sort;
	}

	public long getWeight() {
		return weight;
	}

	public void setWeight(long weight) {
		this.weight = weight;
	}
	

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public String getLocationName() {
        return locationName;
    }

    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }

    @Override
    public int compareTo(TwitterResult other) {
    	if (this.Sort == 0) {
        return Long.compare(other.followerCount, this.followerCount); }
    	else  if (this.Sort == 1) {
            return Long.compare(other.retweets, this.retweets); }
    	else if (this.Sort == 2) {
            return Long.compare(other.weight, this.weight); }
    	
    	return Long.compare(other.followerCount, this.followerCount);
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((screenName == null) ? 0 : screenName.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        TwitterResult other = (TwitterResult) obj;
        if (screenName == null) {
            if (other.screenName != null)
                return false;
        } else if (!screenName.equals(other.screenName))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "TwitterResult [tweetId=" + tweetId + ", retweets=" + retweets + ", profileName=" + profileName
                + ", followerCount=" + followerCount + ", screenName=" + screenName + ", proifleImageUrl="
                + proifleImageUrl + ", locationName=" + locationName + ", latitude=" + latitude + ", longitude="
                + longitude + "]";
    }

}