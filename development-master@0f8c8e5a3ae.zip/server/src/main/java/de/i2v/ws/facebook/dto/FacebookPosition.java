package de.i2v.ws.facebook.dto;


import java.io.Serializable;

public class FacebookPosition implements Serializable {

	private static final long serialVersionUID = 6580315427640447383L;

	//
//	private String id = null;
	private String name = null;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}

