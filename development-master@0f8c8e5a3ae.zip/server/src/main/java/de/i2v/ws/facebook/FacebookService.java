package de.i2v.ws.facebook;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;

@Service
public class FacebookService {

	@Autowired
	private FacebookRestTemplate facebook;

	/**
	 * Returns the summed likes of all* facebook pages with the given keywords
	 * in either name or category (I guess, could be more).
	 * 
	 * Example: https://graph.facebook.com/v2.2/
	 * "search?q=keyword&type=page&fields=likes"
	 * 
	 * *facebook caps the results at arround 500
	 * 
	 * @param keywords
	 *            the search words, separated by whitespace
	 * @return
	 */
	public long getPageLikeCount(String keywords) {
		String query = "search?q=" + keywords + "&type=page&fields=fan_count";

		String response = facebook.getForEntity(query, String.class).getBody();

		return countLikesFromResponse(response);
	}

	private long countLikesFromResponse(String response) {
		long likecount = 0;
		
		//return 4542;
        if (response != null)
        {
		ObjectMapper mapper = new ObjectMapper();
		try {
			for (JsonNode objNode : mapper.readTree(response).get("data")) {
				likecount += objNode.get("fan_count").asInt();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
			return likecount;
        }
        else
        {
        	return 0;
        }
	}
}
