package de.i2v.ws.endpoint;

import de.i2v.ws.entity.CodeFlower;
import de.i2v.ws.facebook.FacebookPageResponseDTO;
import de.i2v.ws.facebook.FacebookQueryDTO;
import de.i2v.ws.facebook.FacebookService;
import de.i2v.ws.facebook.FacebookServiceClient;
import de.i2v.ws.service.ICodeflower;
import de.i2v.ws.service.ICountService;
import de.i2v.ws.service.ISearchService;
import de.i2v.ws.service.IShare;
import de.i2v.ws.twitter.TwitterResult;
import de.i2v.ws.twitter.TwitterService;
import de.i2v.ws.twitter.domain.TwitterUsers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.json.MappingJacksonValue;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;


@RequestMapping("marketAnalysis")
@RestController
public class MarketAnalysisEndpoint {

    @Autowired
    IShare shareService;

    @Autowired
    private FacebookService facebookService;
    
    @Autowired
    private TwitterService twitterService;

    @Autowired
    private ICountService countService;

    @Autowired
    private ISearchService searchService;

    @Autowired
    private ICodeflower codeflowerService;

    private class SocialShare {
        private String network;
        private String keyword;
        private long timestamp;

        public String getNetwork() {
            return network;
        }

        public String getKeyword() {
            return keyword;
        }

        public long getTimestamp() {
            return timestamp;
        }

        public SocialShare(String network, String keyword, long timestamp) {
            this.network = network;
            this.keyword = keyword;
            this.timestamp = timestamp;
        }
    }

    private class CodeFlowerNode {
        private String name;
        private int size;
        private List<CodeFlowerNode> children = new ArrayList<>();

        public CodeFlowerNode(String name, int size) {
            this.name = name;
            this.size = size;
        }

        public CodeFlowerNode(String name) {
            this.name = name;
        }

        public String getName() {
            return name;
        }

        public int getSize() {
            if (this.children.isEmpty()) {// Leaf node
                return size;
            } else {
                return this.children.stream().mapToInt(CodeFlowerNode::getSize).sum();
            }
        }

        public List<CodeFlowerNode> getChildren() {
            return children;
        }
    }

    @ResponseBody
    @RequestMapping(value = "size", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public MappingJacksonValue getMarketSize(@RequestParam String keywords, @RequestParam String callback) {
        Result res = new Result();
        FacebookServiceClient facebookServiceClient = new FacebookServiceClient( "128640984441847|bf86eb19e5a08982e1dc20c5b6b85750");
        res.count = facebookServiceClient.getPageLikes(keywords);
        MappingJacksonValue value = new MappingJacksonValue(res);
        value.setJsonpFunction(callback);
        return value;
    }
    
    @ResponseBody
    @RequestMapping(value = "pages", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public MappingJacksonValue getKeyPages(@RequestParam(required = false) Integer distance,
                                           @RequestParam(required = false) String age, @RequestParam(required = false) String region,
                                           @RequestParam String keywords, @RequestParam String callback) {
        System.out.println("distance: " + distance + ", age:" + age + ", region:" + ":" + region + ", keywords: "
                + keywords);
    	FacebookServiceClient facebookServiceClient = new FacebookServiceClient( "128640984441847|bf86eb19e5a08982e1dc20c5b6b85750");
    	Collection<FacebookPageResponseDTO> values  = facebookServiceClient.getPageResponse(keywords);
//    	List<TwitterResult> res = values;
    	  List<FacebookPageResponseDTO> list = new ArrayList<FacebookPageResponseDTO>(
	                values);
        MappingJacksonValue value = new MappingJacksonValue(list);
        value.setJsonpFunction(callback);
        return value;
    }
    
    @ResponseBody
    @RequestMapping(value = "pagesComments", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public MappingJacksonValue getKeyPagesC(@RequestParam(required = false) Integer distance,
                                            @RequestParam(required = false) String age, @RequestParam(required = false) String region,
                                            @RequestParam String keywords, @RequestParam(required = false) Integer count, @RequestParam(required = false) Integer sort, @RequestParam String callback) {
        System.out.println("distance: " + distance + ", age:" + age + ", region:" + ":" + region + ", keywords: "
                + keywords);
        
    	FacebookServiceClient facebookServiceClient = new FacebookServiceClient( "128640984441847|bf86eb19e5a08982e1dc20c5b6b85750");
    	Collection<FacebookPageResponseDTO> pageDtos  = facebookServiceClient.getPageResponse(keywords);
    	if (count == 0)
		{ count = 10; }
    		String[] pageids = new String[count];
    		if(pageDtos.size() >= 1 )
    		{
    			int k = 0;
    			for (FacebookPageResponseDTO facebookPageResponseDTO : pageDtos) {
    				pageids[k] = facebookPageResponseDTO.getPageId();
    				k++;
    				if (k == count) {
    				break;
    				}
    			}
	
		
		Collection<FacebookQueryDTO> values  = facebookServiceClient.getResponse(keywords, count, count,
				pageids, sort);
    	  List<FacebookQueryDTO> list = new ArrayList<FacebookQueryDTO>(
	                values);
        MappingJacksonValue value = new MappingJacksonValue(list);
        value.setJsonpFunction(callback);
        return value;
		}
		else
		{ 
			MappingJacksonValue values = null;
			return values;		
			
		}
        
    }
    
    /**
     * Gets the list of people with the highest popular facebook for a specific keyword by specidic radius ranges like
     * 1km, 10km, 100km, 1000km and 10000km from the source location with coordinates passed here as parameters.
     * 
     * @param latitude the latitude
     * @param longitude the longitude
     * @param age the age
     * @param region the region
     * @param keywords the keywords
     * @param callback the callback
     * @return the persons count by distance
     */
    @ResponseBody
    @RequestMapping(value = "fbLocation", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public MappingJacksonValue getfbPersonsCountByDistance(@RequestParam(required = false) Double latitude,
                                                           @RequestParam(required = false) Double longitude, @RequestParam(required = false) String age,
                                                           @RequestParam(required = false) String region, @RequestParam String keywords, @RequestParam(required = false) Integer distance, @RequestParam(required = false) Integer count, @RequestParam(required = false) Integer sort, @RequestParam String callback) {

        System.out.println(keywords + "," + region + "," + age + "," + latitude + "," + longitude);
        FacebookServiceClient facebookServiceClient = new FacebookServiceClient( "128640984441847|bf86eb19e5a08982e1dc20c5b6b85750");
    	Collection<FacebookPageResponseDTO> pageDtos  = facebookServiceClient.getPageResponse(keywords);
    	if (count == 0)
    		{ count = 10; }
		String[] pageids = new String[count];
		if(pageDtos.size() >= 1 )
		{
		int k = 0;
		for (FacebookPageResponseDTO facebookPageResponseDTO : pageDtos) {
			pageids[k] = facebookPageResponseDTO.getPageId();
			k++;
			if (k == count) {
				break;
			}
		}
	
		
		Collection<FacebookQueryDTO> values  = facebookServiceClient.getResponseLoc(keywords, count, count,
				pageids,latitude, longitude, distance, sort);
    	  List<FacebookQueryDTO> list = new ArrayList<FacebookQueryDTO>(
	                values);
        MappingJacksonValue value = new MappingJacksonValue(list);
        value.setJsonpFunction(callback);
        return value;
		}
		else
		{ 
			MappingJacksonValue values = null;
			return values;		
		}
    }

    @ResponseBody
    @RequestMapping(value = "persons", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public MappingJacksonValue getKeyPersons(@RequestParam(required = false) Integer distance,
                                             @RequestParam(required = false) String age, @RequestParam(required = false) String region,
                                             @RequestParam String keywords, @RequestParam(required = false) Integer count, @RequestParam(required = false) Integer sort, @RequestParam String callback) {
        System.out.println("distance: " + distance + ", age:" + age + ", region:" + ":" + region + ", keywords: "
                + keywords);
        List<TwitterResult> res = twitterService.findPopularTweetsWithUsers(keywords, region, age, distance, count, sort);
        MappingJacksonValue value = new MappingJacksonValue(res);
        value.setJsonpFunction(callback);
        return value;
    }

    /**
     * Gets the list of people with the highest popular tweets for a specific keyword by specidic radius ranges like
     * 1km, 10km, 100km, 1000km and 10000km from the source location with coordinates passed here as parameters.
     * 
     * @param latitude the latitude
     * @param longitude the longitude
     * @param age the age
     * @param region the region
     * @param keywords the keywords
     * @param callback the callback
     * @return the persons count by distance
     */
    @ResponseBody
    @RequestMapping(value = "personsCount", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public MappingJacksonValue getPersonsCountByDistance(@RequestParam(required = false) Double latitude,
                                                         @RequestParam(required = false) Double longitude, @RequestParam(required = false) String age,
                                                         @RequestParam(required = false) String region, @RequestParam String keywords, @RequestParam(required = false) Integer sort, @RequestParam String callback) {

        System.out.println(keywords + "," + region + "," + age + "," + latitude + "," + longitude);
        TwitterUsers twitterUsers = twitterService.findUserCountByDistance(keywords, region, age, latitude, longitude, sort);
        System.out.println(twitterUsers);
        MappingJacksonValue value = new MappingJacksonValue(twitterUsers);
        value.setJsonpFunction(callback);

        return value;
    }

    @ResponseBody
    @RequestMapping(value = "share", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public MappingJacksonValue saveShare(@RequestParam String network, @RequestParam Set<String> keywordList,
                                         @RequestParam String callback) {
        System.out.println("*******saveShare********");
        // System.out.println("URL: " + keyword);
        MappingJacksonValue value = new MappingJacksonValue(true);
        try {
            String forHit = "Share";
            boolean b = countService.saveCount(keywordList, network, forHit);
            System.out.println("RESULT: " + b);

            value.setJsonpFunction(callback);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return value;

    }

    @ResponseBody
    @RequestMapping(value = "generateCodeFlowerJson", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public MappingJacksonValue generateCodeFlower(@RequestParam String callback) throws Exception {
        System.out.println("method called");
        MappingJacksonValue value = null;
        try {
            CodeFlower codeFlower = codeflowerService.generateSharingCodeflower();
            value = new MappingJacksonValue(codeFlower);
            value.setJsonpFunction(callback);
            // Gson gson = new Gson();
            // return gson.toJson(codeFlower);
            return value;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;

    }

    public class Result {
        public Long count;
    }

    @ResponseBody
    @RequestMapping(value = "countdetail", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public MappingJacksonValue saveHitback(@RequestParam Set<String> keywordList, @RequestParam String channel,
                                           @RequestParam String callback) {
        String forHit = "Hitback";
        MappingJacksonValue value = new MappingJacksonValue(true);
        try {
            countService.saveCount(keywordList, channel, forHit);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return value;
    }

    @ResponseBody
    @RequestMapping(value = "searchkeywordcount", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.OK)
    public MappingJacksonValue saveSearch(@RequestParam String keyword, @RequestParam String callback) {
        MappingJacksonValue value = new MappingJacksonValue(true);
        try {
            searchService.saveSearchCount(keyword);
            value.setJsonpFunction(callback);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return value;
    }
}
