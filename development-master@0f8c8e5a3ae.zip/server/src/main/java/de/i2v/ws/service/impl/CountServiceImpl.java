package de.i2v.ws.service.impl;

import de.i2v.ws.config.DatabaseConnection;
import de.i2v.ws.service.ICountService;
import org.springframework.stereotype.Service;

import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Set;

@Service
public class CountServiceImpl implements ICountService {

    static Connection connection;

    @Override
    public boolean saveCount(Set<String> keywardList, String channel, String countFor) throws Exception,
            URISyntaxException, SQLException {
        try {
            connection = DatabaseConnection.getConnection();

            // check for key existence
            System.out.println("check for key existence");

            for (String keyward : keywardList) {

                PreparedStatement checkStatement = connection
                        .prepareStatement("Select * from count_detail where channel=? and keyword=?");
                checkStatement.setString(1, channel);
                checkStatement.setString(2, keyward);
                ResultSet resultSet = checkStatement.executeQuery();

                if (resultSet.next()) {
                    int count;
                    String sql;
                    if (countFor.equals("Hitback")) {
                        // if exists. then update
                        System.out.println("if exists. then update: " + keyward);
                        count = resultSet.getInt("hb_count");
                        count++;
                        sql = "UPDATE count_detail set hb_count=? WHERE channel=? and keyword=?";

                    } else {
                        // if exists. then update
                        System.out.println("if exists. then update: " + keyward);
                        count = resultSet.getInt("share_count");
                        count++;
                        sql = "UPDATE count_detail set share_count=? WHERE channel=? and keyword=?";
                        checkStatement.execute();
                    }

                    checkStatement = connection.prepareStatement(sql);
                    checkStatement.setInt(1, count);
                    checkStatement.setString(2, channel);
                    checkStatement.setString(3, keyward);

                    checkStatement.execute();

                } else {
                    // if not. then add
                    saveCountDetail(keyward, channel, countFor);
                }
            }

        } catch (Exception exception) {
            System.err.println("saveCount failed: " + exception);
        } finally {
            connection.close();
        }
        return true;
    }

    private boolean saveCountDetail(String keyward, String channel, String countFor) throws Exception {

        System.out.println("if not. then add: " + keyward);
        PreparedStatement insertStatement = connection
                .prepareStatement("INSERT INTO count_detail VALUES (?, ?, ?, ?, ?)");
        insertStatement.setInt(1, 1);
        insertStatement.setString(2, keyward);
        insertStatement.setString(3, channel);
        if (countFor.equals("Hitback")) {
            insertStatement.setInt(4, 1);
            insertStatement.setInt(5, 0);
        } else {
            insertStatement.setInt(4, 0);
            insertStatement.setInt(5, 1);
        }
        insertStatement.executeUpdate();
        return true;
    }
}