package de.i2v.ws.facebook.dto;


public class FacebookPosts {
	 private FacebookPostsData posts;

	public FacebookPostsData getPosts() {
		return posts;
	}

	public void setPosts(FacebookPostsData posts) {
		this.posts = posts;
	}
}
