package de.i2v.ws.facebook.dto;

public class FacebookPicture {
	private FacebookPictureUrl data;

	public FacebookPictureUrl getData() {
		return data;
	}

	public void setData(FacebookPictureUrl data) {
		this.data = data;
	}
}
