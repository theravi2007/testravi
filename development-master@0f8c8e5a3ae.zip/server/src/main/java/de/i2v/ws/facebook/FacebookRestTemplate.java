package de.i2v.ws.facebook;

import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RequestCallback;
import org.springframework.web.client.ResponseExtractor;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.net.URISyntaxException;

@Repository
public class FacebookRestTemplate extends RestTemplate {

	private static String facebookUrl = "https://graph.facebook.com/v2.7/";

	private static String clientId = "632760180213839";
	private static String clientSecret = "4f5fdf6654ed74e4c1bc0298cfe457cc";

	@Override
	protected <T> T doExecute(URI url, HttpMethod method, RequestCallback requestCallback,
                              ResponseExtractor<T> responseExtractor) throws RestClientException {
		url = buildUri(url);
		return super.doExecute(url, method, requestCallback, responseExtractor);

	}

	private URI buildUri(URI uri) throws RestClientException {
		String newUrl = facebookUrl + uri.toString() + "&access_token=" + clientId + "%7C" + clientSecret;

		try {
			return uri = new URI(newUrl);
		} catch (URISyntaxException e) {
			throw new RestClientException("Couldn't build new URI " + newUrl, e);
		}
	}

}