package de.i2v.ws.facebook;

import com.restfb.*;
import com.restfb.json.JsonArray;
import com.restfb.json.JsonObject;
import com.restfb.types.Group;
import com.restfb.types.Page;
import com.restfb.types.Post;

import java.util.*;


public class FacebookServiceClient {
	private String accessToken;
	public final static double AVERAGE_RADIUS_OF_EARTH = 6371;
	public FacebookServiceClient(String accesstoken) {
		this.accessToken = accesstoken;
		/*
		 * configService = ApplicationContextProvider
		 * .getBeanByType(ConfigService.class);
		 */
	}

	/**
     * This method takes the query as an input parameter and return the group response data
     * 
     * @param query
     */
    @Deprecated
    public void getGroupResponse(String query) {
        try {
            FacebookClient facebookClient = new DefaultFacebookClient(accessToken, Version.VERSION_2_6);
            Connection<Group> groupSearch = facebookClient.fetchConnection("search", Group.class, Parameter.with("q", query),
                    Parameter.with("fields", "id,name,likes,privacy"), Parameter.with("type", "group"), Parameter.with("limit", "500"));
            int privateGroups = 0;
            int publicGroups = 0;
            for(Group group : groupSearch.getData()) {
                JsonObject friendList = facebookClient.fetchObject(group.getId() + "/members", JsonObject.class,
                        Parameter.with("fields", "name,id,location,email,hometown,age_range"));
                JsonArray array = (JsonArray) friendList.get("data");
                if(group.getPrivacy().equals("CLOSED")) {
                    privateGroups++;
                    System.out.println("Group Name:" + group.getName() + ",Group Type:" + group.getPrivacy());

                } else if(group.getPrivacy().equals("OPEN")) {
                    publicGroups++;
                    System.out.println("Group Name:" + group.getName() + ", Member Count:" + array.length() + ",Group Type:" + group.getPrivacy());
                }
                for(int i = 0; i < array.length(); i++) {
                    JsonObject jsonObject = (JsonObject) array.get(0);
                    try {
                        System.out.println("Age Range Found" + jsonObject.get("age_range"));
                    } catch(Exception e) {
                        // System.out.println("No Location Found");
                    }
                }
            }
            System.out.println("Public Groups:" + publicGroups + ", Closed/Private Groups" + privateGroups);

        } catch(Exception e) {
            e.printStackTrace();
        }

    }

    /**
     * This is code for most influencing pages
     * 
     * @param query
     * @return
     */
    public Set<FacebookPageResponseDTO> getPageResponse(String query) {
        int PAGE_RESULT_SIZE = 6;
        long startTime = System.currentTimeMillis();
        FacebookClient facebookClient = new DefaultFacebookClient(accessToken, Version.VERSION_2_6);
        // Two files one file input.txt and one output.txt
        Connection<Page> pageSearch = facebookClient.fetchConnection("search", Page.class, Parameter.with("q", query),
                Parameter.with("fields", "name,fan_count,were_here_count"), Parameter.with("type", "page"));
        Set<FacebookPageResponseDTO> pages = new TreeSet<FacebookPageResponseDTO>();
        List<String> list = new ArrayList<String>();
        for(Page page : pageSearch.getData()) {
            list.add(page.getId());
        }
        for(int i = 0; i < list.size() / PAGE_RESULT_SIZE; i++) {
            int fromIndex = i * PAGE_RESULT_SIZE;
            int toIndex = (i + 1) * PAGE_RESULT_SIZE > list.size() ? list.size() : (i + 1) * PAGE_RESULT_SIZE;
            JsonObject jb = facebookClient.fetchObjects(list.subList(fromIndex, toIndex), JsonObject.class,
                    Parameter.with("fields", "name,fan_count,were_here_count,website,about,talking_about_count,description, picture"));
            Iterator<String> iter = (Iterator<String>) jb.keys();
            while(iter.hasNext()) {
                FacebookPageResponseDTO facebookPageResponseDTO = new FacebookPageResponseDTO();
                JsonObject jsonObject = (JsonObject) jb.get(iter.next());
                facebookPageResponseDTO.setPageId(jsonObject.getString("id"));
                facebookPageResponseDTO.setLikesCount(jsonObject.getLong("fan_count"));
                facebookPageResponseDTO.setVisitCount(jsonObject.getLong("were_here_count"));
                facebookPageResponseDTO.setPageName(jsonObject.getString("name"));
                if(jsonObject.has("website")) {
                    facebookPageResponseDTO.setWebsite(jsonObject.getString("website"));
                }
                if(jsonObject.has("about")) {
                    facebookPageResponseDTO.setAbout(jsonObject.getString("about"));
                }
                if(jsonObject.has("talking_about_count")) {
                    facebookPageResponseDTO.setMentionsCount(jsonObject.getString("talking_about_count"));
                }
                if(jsonObject.has("description")) {
                    facebookPageResponseDTO.setDescription(jsonObject.getString("description"));
                }
                
                if(jsonObject.has("picture")) {
                	 facebookPageResponseDTO.setPicture(jsonObject.getString("picture"));
                }
                pages.add(facebookPageResponseDTO);
            }
        }
        System.out.println("Time taken by Facebook:" + (System.currentTimeMillis() - startTime));
        return pages;
    }

    /**
     * Retrieval of users We first search for pages which match the keyword and we take the top pageCount pages and search for posts/statuses with most number
     * of comments
     * 
     * Ranking is done based on number of comments if two results have same comment count then we take number of likes as second priority
     * 
     * @param query
     * @param pagecount
     * @param count
     * @param pageIds
     * @return
     */
    public Set<FacebookQueryDTO> getResponse(String query, int pagecount, Integer count, String[] pageIds, int sort) {
        FacebookClient facebookClient = new DefaultFacebookClient(accessToken, Version.VERSION_2_6);
        // Two files one file input.txt and one output.txt
        List<JsonObject> pageStatuses = new ArrayList<JsonObject>();
        for(String pageId : pageIds) {
            JsonObject statuses = facebookClient.fetchObject(pageId + "/posts", JsonObject.class, Parameter.with("limit", count));
            JsonArray jsonData = statuses.getJsonArray("data");
            if(jsonData.length() > 0) {
                pageStatuses.add(statuses);
            }
        }
        Set<FacebookQueryDTO> posts = new TreeSet<FacebookQueryDTO>();
        for(JsonObject statuses : pageStatuses) {
            // JsonObject status = statuses.getJsonObject("paging");
            JsonArray jsonData = statuses.getJsonArray("data");
            int oCount = 0;
            String postId = null;
            Post postMain = null;
            String postMainId = postId;
            for(int i = 0; i < jsonData.length(); i++) {
                JsonObject rec = jsonData.getJsonObject(i);
                postId = rec.getString("id");
                Post post = facebookClient.fetchObject(postId,
                        Post.class,
                        Parameter.with("fields", "from,to,likes.limit(0).summary(true),comments.limit(0).summary(true),shares.limit(0).summary(true), picture, message"));
                if( oCount == 0)
                	{
                	postMain = post;
                	postMainId = postId;
                	oCount++;
                	}
                if(post.getCommentsCount().intValue() > 0 && post.getCommentsCount().intValue()  > postMain.getCommentsCount().intValue())
                { 
                	postMain = post;
                	postMainId = postId;
                	
                }
            }
                    FacebookQueryDTO facebookQueryDTO = new FacebookQueryDTO();
					facebookQueryDTO.setpostId(postMainId);
                    facebookQueryDTO.setLikesCount(postMain.getLikesCount().intValue());
                    facebookQueryDTO.setSharesCount(postMain.getSharesCount().intValue());
                    facebookQueryDTO.setCommentsCount(postMain.getCommentsCount().intValue());                    
                    facebookQueryDTO.setWeight(postMain.getLikesCount().intValue() * postMain.getCommentsCount().intValue());
                    facebookQueryDTO.setPicture(postMain.getPicture());
                    facebookQueryDTO.setStatusMessage(postMain.getMessage());
                    facebookQueryDTO.setSort(sort);
                    String result[] = postId.split("_");
                    String PageId = result[0];
                    Page page = facebookClient.fetchObject(PageId, Page.class,
        					Parameter.with("fields", "name, location"));
        			
        			if (page.getLocation() != null) {
        				if (page.getLocation().getLongitude() != null) {
        					facebookQueryDTO.setLongitude(page.getLocation()
        							.getLongitude().doubleValue());
        				}

        				if (page.getLocation().getLatitude() != null) {
        					facebookQueryDTO.setLatitude(page.getLocation()
        							.getLatitude().doubleValue());
        				}
        				if (page.getLocation().getCity() != null) {
        					facebookQueryDTO.setCity(page.getLocation().getCity());
        				}
        			}
        			
        			if (page.getName()!= null) {
        				facebookQueryDTO.setUserName(page.getName().toString());
        			}
                    
                    posts.add(facebookQueryDTO);
                    oCount = 0;
        }
        return posts;
    }
    
    public long getPageLikes(String query) {
		FacebookClient facebookClient = new DefaultFacebookClient(accessToken,
				Version.VERSION_2_6);

		long sumLikes = 0;
		Connection<Page> pageConnection2 = facebookClient.fetchConnection(
				"search", Page.class, Parameter.with("q", query),
				Parameter.with("type", "page"),
				Parameter.with("fields", "fan_count"));
		for (List<Page> singlePage : pageConnection2) {
			for (Page p : singlePage) {
				sumLikes += p.getFanCount();
			}
		}

		return sumLikes;
	}
    
    /**
     * This is code for most influencing pages
     * 
     * @param query
     * @return
     */
    public Set<FacebookPageResponseDTO> getPageResponse(String query,
                                                        double lat1, double lng1, int distance){
        int PAGE_RESULT_SIZE = 6;
        long startTime = System.currentTimeMillis();
        FacebookClient facebookClient = new DefaultFacebookClient(accessToken, Version.VERSION_2_6);
        // Two files one file input.txt and one output.txt
        Connection<Page> pageSearch = facebookClient.fetchConnection("search", Page.class, Parameter.with("q", query),
                Parameter.with("fields", "name,fan_count,were_here_count"), Parameter.with("type", "page"), Parameter.with("fields", "location"));
        Set<FacebookPageResponseDTO> pages = new TreeSet<FacebookPageResponseDTO>();
        List<String> list = new ArrayList<String>();
        for(Page page : pageSearch.getData()) {
        	if (page.getLocation() != null) {
				if (page.getLocation().getLongitude() != null
						&& page.getLocation().getLatitude() != null) {
					int vald;
					if (calculateDistance(lat1, lng1, page.getLocation().getLatitude(),
							page.getLocation().getLongitude()) <= (distance))
					
						list.add(page.getId());
				}
			}
        }
        for(int i = 0; i < list.size() / PAGE_RESULT_SIZE; i++) {
            int fromIndex = i * PAGE_RESULT_SIZE;
            int toIndex = (i + 1) * PAGE_RESULT_SIZE > list.size() ? list.size() : (i + 1) * PAGE_RESULT_SIZE;
            JsonObject jb = facebookClient.fetchObjects(list.subList(fromIndex, toIndex), JsonObject.class,
                    Parameter.with("fields", "name,fan_count,were_here_count,website,about,talking_about_count,description, picture"));
            Iterator<String> iter = (Iterator<String>) jb.keys();
            while(iter.hasNext()) {
                FacebookPageResponseDTO facebookPageResponseDTO = new FacebookPageResponseDTO();
                JsonObject jsonObject = (JsonObject) jb.get(iter.next());
                facebookPageResponseDTO.setPageId(jsonObject.getString("id"));
                facebookPageResponseDTO.setLikesCount(jsonObject.getLong("fan_count"));
                facebookPageResponseDTO.setVisitCount(jsonObject.getLong("were_here_count"));
                facebookPageResponseDTO.setPageName(jsonObject.getString("name"));
                if(jsonObject.has("website")) {
                    facebookPageResponseDTO.setWebsite(jsonObject.getString("website"));
                }
                if(jsonObject.has("about")) {
                    facebookPageResponseDTO.setAbout(jsonObject.getString("about"));
                }
                if(jsonObject.has("talking_about_count")) {
                    facebookPageResponseDTO.setMentionsCount(jsonObject.getString("talking_about_count"));
                }
                if(jsonObject.has("description")) {
                    facebookPageResponseDTO.setDescription(jsonObject.getString("description"));
                }
                
                if(jsonObject.has("picture")) {
                	 facebookPageResponseDTO.setPicture(jsonObject.getString("picture"));
                }
                pages.add(facebookPageResponseDTO);
            }
        }
        System.out.println("Time taken by Facebook:" + (System.currentTimeMillis() - startTime));
        return pages;
    }
    
    
    public int calculateDistance(double userLat, double userLng,
			  double venueLat, double venueLng) {

			    double latDistance = Math.toRadians(userLat - venueLat);
			    double lngDistance = Math.toRadians(userLng - venueLng);

			    double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
			      + Math.cos(Math.toRadians(userLat)) * Math.cos(Math.toRadians(venueLat))
			      * Math.sin(lngDistance / 2) * Math.sin(lngDistance / 2);

			    double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

			    return (int) (Math.round(AVERAGE_RADIUS_OF_EARTH * c));
			}
    
    
    /**
     * Retrieval of users We first search for pages which match the keyword and we take the top pageCount pages and search for posts/statuses with most number
     * of comments
     * 
     * Ranking is done based on number of comments if two results have same comment count then we take number of likes as second priority
     * 
     * @param query
     * @param pagecount
     * @param count
     * @param pageIds
     * @return
     */
    public Set<FacebookQueryDTO> getResponseLoc(String query, int pagecount, Integer count, String[] pageIds, double lat1, double lng1, int distance, int sort) {
        FacebookClient facebookClient = new DefaultFacebookClient(accessToken, Version.VERSION_2_6);
        // Two files one file input.txt and one output.txt
        List<JsonObject> pageStatuses = new ArrayList<JsonObject>();
        for(String pageId : pageIds) {
            JsonObject statuses = facebookClient.fetchObject(pageId + "/posts", JsonObject.class, Parameter.with("limit", count));
            JsonArray jsonData = statuses.getJsonArray("data");
            if(jsonData.length() > 0) {
                pageStatuses.add(statuses);
            }
        }
        Set<FacebookQueryDTO> posts = new TreeSet<FacebookQueryDTO>();
        for(JsonObject statuses : pageStatuses) {
            // JsonObject status = statuses.getJsonObject("paging");
            JsonArray jsonData = statuses.getJsonArray("data");
            int oCount = 0;
            String postId = null;
            Post postMain = null;
            String postMainId = postId;
            for(int i = 0; i < jsonData.length(); i++) {
                JsonObject rec = jsonData.getJsonObject(i);
                postId = rec.getString("id");
                Post post = facebookClient.fetchObject(postId,
                        Post.class,
                        Parameter.with("fields", "from,to,likes.limit(0).summary(true),comments.limit(0).summary(true),shares.limit(0).summary(true), picture, message"));
                if( oCount == 0)
                	{
                	postMain = post;
                	postMainId = postId;
                	oCount++;
                	}
                if(post.getCommentsCount().intValue() > 0 && post.getCommentsCount().intValue()  > postMain.getCommentsCount().intValue())
                { 
                	postMain = post;
                	postMainId = postId;
                	
                }
            }
            FacebookQueryDTO facebookQueryDTO = new FacebookQueryDTO();
    		facebookQueryDTO.setpostId(postMainId);
    		facebookQueryDTO.setLikesCount(postMain.getLikesCount().intValue());
    		facebookQueryDTO.setSharesCount(postMain.getSharesCount().intValue());
    		facebookQueryDTO.setCommentsCount(postMain.getCommentsCount()
    				.intValue());
    		facebookQueryDTO.setWeight(postMain.getLikesCount().intValue() * postMain.getCommentsCount().intValue());
    		facebookQueryDTO.setPicture(postMain.getPicture());
    		facebookQueryDTO.setStatusMessage(postMain.getMessage());
    		facebookQueryDTO.setSort(sort);
    		String result[] = postId.split("_");
    		String PageId = result[0];
    		Page page = facebookClient.fetchObject(PageId, Page.class,
    				Parameter.with("fields", "name, location"));
    		if (page.getLocation() != null) {
    			if (page.getLocation().getLongitude() != null) {
    				facebookQueryDTO.setLongitude(page.getLocation().getLongitude()
    						.doubleValue());
    			}

    			if (page.getLocation().getLatitude() != null) {
    				facebookQueryDTO.setLatitude(page.getLocation().getLatitude()
    						.doubleValue());
    			}
    			if (page.getLocation().getCity() != null) {
    				facebookQueryDTO.setCity(page.getLocation().getCity());
    			}
    			
    			if (page.getLocation().getCountry() != null) {
    				facebookQueryDTO.setCountry(page.getLocation().getCountry());
    			}
    			
    			if (page.getName()!= null) {
    				facebookQueryDTO.setUserName(page.getName().toString());
    			}
    			
    			if (page.getLocation().getLongitude() != null
    					&& page.getLocation().getLatitude() != null) {
    				int vald;
    				if (calculateDistance(lat1, lng1, page.getLocation()
    						.getLatitude(), page.getLocation().getLongitude()) <= 1) {
    					facebookQueryDTO.setDistance(1);

    				} else if (calculateDistance(lat1, lng1, page.getLocation()
    						.getLatitude(), page.getLocation().getLongitude()) <= 10) {
    					facebookQueryDTO.setDistance(10);

    				} else if (calculateDistance(lat1, lng1, page.getLocation()
    						.getLatitude(), page.getLocation().getLongitude()) <= 100) {
    					facebookQueryDTO.setDistance(100);

    				} else if (calculateDistance(lat1, lng1, page.getLocation()
    						.getLatitude(), page.getLocation().getLongitude()) <= 1000) {
    					facebookQueryDTO.setDistance(100);

    				} else if (calculateDistance(lat1, lng1, page.getLocation()
    						.getLatitude(), page.getLocation().getLongitude()) <= 10000) {
    					facebookQueryDTO.setDistance(10000);

    				} else  {
    					facebookQueryDTO.setDistance(10001);
    				}
    			}
    		}
    		posts.add(facebookQueryDTO);
    		oCount = 0;
        }
        return posts;
    }
    
    
}