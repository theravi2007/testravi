package de.i2v.ws.twitter.domain;

import de.i2v.ws.twitter.TwitterResult;

import java.util.List;

public class CountByDistance {

    public CountByDistance(int key, int count) {

        this.label = (key == -1 ? "UNKNOWN" : key) + " Km ";
        this.count = count;
        this.distance = key;
    }

    public String label;
    public int distance = 0;
    public int count;
    public List<TwitterResult> knownUsers;
    public List<TwitterResult> unknownUsers;

    public List<TwitterResult> getKnownUsers() {
        return knownUsers;
    }

    public void setKnownUsers(List<TwitterResult> knownUsers) {
        this.knownUsers = knownUsers;
    }

    public List<TwitterResult> getUnknownUsers() {
        return unknownUsers;
    }

    public void setUnknownUsers(List<TwitterResult> unknownUsers) {
        this.unknownUsers = unknownUsers;
    }

    @Override
    public String toString() {
        return "CountByDistance [label=" + label + ", distance=" + distance + ", count=" + count + ", knownUsers="
                + knownUsers + ", unknownUsers=" + unknownUsers + "]";
    }

}
