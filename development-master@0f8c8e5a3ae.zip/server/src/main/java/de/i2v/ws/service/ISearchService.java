package de.i2v.ws.service;

import java.net.URISyntaxException;
import java.sql.SQLException;

public interface ISearchService {

    public boolean saveSearchCount(String keyword) throws Exception, URISyntaxException, SQLException;

}