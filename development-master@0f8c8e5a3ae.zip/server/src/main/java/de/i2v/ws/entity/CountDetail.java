package de.i2v.ws.entity;

public class CountDetail {

    private int id;
    private String keyword;
    private String channel;
    private int hbcount;
    private int sharecount;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }

    public String getChannel() {
        return channel;
    }

    public void setChannel(String channel) {
        this.channel = channel;
    }

    public int getHbcount() {
        return hbcount;
    }

    public void setHbcount(int hbcount) {
        this.hbcount = hbcount;
    }

    public int getSharecount() {
        return sharecount;
    }

    public void setSharecount(int sharecount) {
        this.sharecount = sharecount;
    }

    @Override
    public String toString() {
        return "CountDetail [id=" + id + ", keyword=" + keyword + ", channel=" + channel + ", hbcount=" + hbcount
                + ", sharecount=" + sharecount + "]";
    }
}