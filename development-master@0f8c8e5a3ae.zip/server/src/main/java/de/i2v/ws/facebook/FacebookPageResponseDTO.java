package de.i2v.ws.facebook;

public class FacebookPageResponseDTO implements
Comparable<FacebookPageResponseDTO> {
private long likesCount;
private long visitCount;
private String pageId;
private String pageName;
private String website;
private String about;
private String mentionsCount;
private String description;
private String picture;

public long getLikesCount() {
return likesCount;
}

public void setLikesCount(long likesCount) {
this.likesCount = likesCount;
}

public String getPageId() {
return pageId;
}

public void setPageId(String pageId) {
this.pageId = pageId;
}

public String getPageName() {
return pageName;
}

public void setPageName(String pageName) {
this.pageName = pageName;
}

public int compareTo(FacebookPageResponseDTO o) {
if (this.getLikesCount() < o.getLikesCount()) {
	return 1;
} else if (this.getLikesCount() > o.getLikesCount()) {
	return -1;
} else {
	int count = Integer.parseInt(this.getMentionsCount());
	int newCount = Integer.parseInt(o.getMentionsCount());
	if (count < newCount) {
		return 1;
	} else if (count > newCount) {
		return -1;
	}
}
return 0;
}

public long getVisitCount() {
return visitCount;
}

public void setVisitCount(long visitCount) {
this.visitCount = visitCount;
}

public String getWebsite() {
return website;
}

public void setWebsite(String website) {
this.website = website;
}

public String getAbout() {
return about;
}

public void setAbout(String about) {
this.about = about;
}

public String getMentionsCount() {
return mentionsCount;
}

public void setMentionsCount(String mentionsCount) {
this.mentionsCount = mentionsCount;
}

public String getDescription() {
return description;
}

public void setDescription(String description) {
this.description = description;
}

public String getPicture() {
return picture;
}

public void setPicture(String picture) {
this.picture = picture;
}
}