package de.i2v.ws.twitter;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import de.i2v.ws.google.GoogleRestTemplate;
import de.i2v.ws.twitter.domain.CountByDistance;
import de.i2v.ws.twitter.domain.TwitterUsers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.*;

@Service
public class TwitterService {
    private java.util.Map<String, String> regionMap = new HashMap<String, String>() {
        {
            put("AL", "");
            put("AP", "14.67614,121.012732");
            put("EU", "54.525961,15.255119");
            put("NA", "54.525961,-105.255119");
            put("LA", "-4.442038,-61.326854");
            put("ME", "29.298528,42.55096");
        }
    };

    private final Integer DEFAULT_VALUE_DISTANCE = 1;
    private final String DEFAULT_UNIT_DISTANCE = "km";

    @Autowired
    private TwitterRestTemplate twitterRest;

    @Autowired
    private GoogleRestTemplate googleRest;

    /**
     * Searches Tweets and returns them with some user data.
     * 
     * Full text search of the tweets body. Example:
     * 
     * https://api.twitter.com/1.1/search/tweets.json?q=frank&count=5
     * 
     * @param keywords the search words, separated by whitespace
     * @param count limit the results, capped at 100
     * @return
     */

    public List<TwitterResult> findPopularTweetsWithUsers(String keywords, int count, int sort) {
        String params = "q=" + keywords + "&count=100";

        String response = twitterRest.getForObject("/1.1/search/tweets.json?" + params, String.class);

        return parseResults(response, count, sort);
    }

    /**
     * Find user count by distance.
     * 
     * @param keywords the keywords
     * @param region the region
     * @param age the age
     * @param radius the radius
     * @param latitude the latitude
     * @param longitude the longitude
     * @return the list
     */
    public TwitterUsers findUserCountByDistance(String keywords, String region, String age, double latitude,
            double longitude, int sort) {
        String response = fetchPopularTweets(keywords, region, age, 1000, 100);
        List<TwitterResult> results = parseResults(response, 100, sort);
        // Categorize the User's into falling radius with respect to User
        // accessing the system
        return parseResultsForCount(longitude, latitude, results);

    }

    public List<TwitterResult> findPopularTweetsWithUsers(String keywords, String region, String age, Integer distance,
            int count, int sort) {
        StringBuilder param = new StringBuilder("q=" + keywords + "&count=100");
        if (region != null && !region.isEmpty()) {
            if (regionMap.get(region) == null) {
                param.append("&geocode=");
                param.append(region);
                param.append(",");
                param.append(DEFAULT_VALUE_DISTANCE);
                param.append(DEFAULT_UNIT_DISTANCE);
            } else if (!regionMap.get(region).isEmpty()) {
                param.append("&geocode=");
                param.append(regionMap.get(region));
                param.append(",");
                param.append(distance == null ? DEFAULT_VALUE_DISTANCE : distance);
                param.append(DEFAULT_UNIT_DISTANCE);
            }
        }

        System.out.println(param.toString());
        String response = twitterRest.getForObject("/1.1/search/tweets.json?" + param.toString(), String.class);
        System.out.println("GOT RESPONSE: " + response);
        return parseResults(response, count, sort);
    }

    private String fetchPopularTweets(String keywords, String region, String age, Integer distance, int count) {

        // set count as 100 to limit the number of calls towards twitter API
        StringBuilder param = new StringBuilder("q=" + keywords + "&count=100");

        // default lang and long
        if (region != null && !region.isEmpty()) {
            if (regionMap.get(region) == null) {
                param.append("&geocode=");
                param.append(region);
                param.append(",");
                param.append(DEFAULT_VALUE_DISTANCE);
                param.append(DEFAULT_UNIT_DISTANCE);
            } else if (!regionMap.get(region).isEmpty()) {
                param.append("&geocode=");
                param.append(regionMap.get(region));
                param.append(",");
                param.append(distance == null ? DEFAULT_VALUE_DISTANCE : distance);
                param.append(DEFAULT_UNIT_DISTANCE);
            }
        }
        String response = twitterRest.getForObject("/1.1/search/tweets.json?" + param.toString(), String.class);
        return response;
    }

    private List<TwitterResult> parseResults(String response, int count, int sort) {
        TreeSet<TwitterResult> results = new TreeSet<>();
        ObjectMapper mapper = new ObjectMapper();
        try {
            for (JsonNode twitterStatus : mapper.readTree(response).get("statuses")) {

                if (twitterStatus.get("retweeted_status") != null)
                    twitterStatus = twitterStatus.get("retweeted_status");

                TwitterResult result = new TwitterResult();
                result.tweetId = twitterStatus.get("id_str").asText();
                result.retweets = twitterStatus.get("retweet_count").asLong();

                JsonNode geo = twitterStatus.get("geo");
                if (!geo.asText().equals("null")) {
                    String coordinate = geo.get("coordinates").toString();
                    coordinate = coordinate.replaceAll("\\[", "");
                    coordinate = coordinate.replaceAll("\\]", "");
                    String[] coordinates = coordinate.split(",");
                    result.latitude = Double.parseDouble(coordinates[0]);
                    result.longitude = Double.parseDouble(coordinates[1]);
                }

                JsonNode user = twitterStatus.get("user");
                result.profileName = user.get("name").asText();
                result.followerCount = user.get("followers_count").asLong();
                result.screenName = user.get("screen_name").asText();
                result.proifleImageUrl = user.get("profile_image_url_https").asText();
                result.locationName = user.get("location").asText();
                result.weight = user.get("followers_count").asLong() * twitterStatus.get("retweet_count").asLong();
                result.Sort = sort;
                results.add(result);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        int sublistIndex = results.size() >= count ? count : results.size();
        return new ArrayList<TwitterResult>(results).subList(0, sublistIndex--);
        // return new ArrayList<TwitterResult>(results);
    }

    /**
     * Parses the results for count.
     * 
     * @param userLon the system user longitude
     * @param userLat the system user latitude
     * @return the twitter users
     */
    private TwitterUsers parseResultsForCount(double userLon, double userLat, List<TwitterResult> users) {

        /* counters for number of user falling under respective radius */
        int countBy1KM = 0;
        int countBy10KM = 0;
        int countBy100KM = 0;
        int countBy1000KM = 0;
        int countBy10000KM = 0;
        int unknown = 0;

        /* Storing into respective sets */
        TreeSet<TwitterResult> knownUserFor1 = new TreeSet<>();
        TreeSet<TwitterResult> knownUserFor10 = new TreeSet<>();
        TreeSet<TwitterResult> knownUserFor100 = new TreeSet<>();
        TreeSet<TwitterResult> knownUserFor1000 = new TreeSet<>();
        TreeSet<TwitterResult> knownUserFor10000 = new TreeSet<>();
        TreeSet<TwitterResult> unknownUser = new TreeSet<>();

        ObjectMapper mapper = new ObjectMapper();

        /* Counter for limited amount of users */
        int count = 0;

        // Ultimate Result storage.
        TwitterUsers twitterUsers = new TwitterUsers();

        try {

            Iterator<TwitterResult> itr = users.iterator();
            while (count <= 100 && itr.hasNext()) {
                count++;
                TwitterResult user = itr.next();
                /* Check for location Name not EMPTY */
                if (user.locationName.isEmpty() || user.getLocationName().contains("@")
                        || user.getLocationName().contains("?")) {
                    /* Location Name Not found. Hence UNKNOWN USER */
                    unknown++;
                    unknownUser.add(user);

                } else {
                    double distance = 0;

                    StringBuilder param = new StringBuilder("address=" + user.locationName);
                    String geoResponse = googleRest.getForObject("/geocode/json?" + param.toString(), String.class);

                    String status = mapper.readTree(geoResponse).get("status").toString();
                    if (status.equals("\"ZERO_RESULTS\"")) {
                        /*
                         * ZERO RESULTS FOUND with this Location Name. Hence UNKNOWN USER
                         */
                        unknown++;
                        unknownUser.add(user);
                    } else {
                        /* Fetching coordinates from the geoCode api response */
                        for (JsonNode geoResult : mapper.readTree(geoResponse).get("results")) {

                            JsonNode geometry = geoResult.get("geometry");
                            JsonNode cordinate = geometry.get("location");
                            String latitude = cordinate.get("lat").toString();
                            String longitude = cordinate.get("lng").toString();
                            user.latitude = Double.parseDouble(latitude);
                            user.longitude = Double.parseDouble(longitude);

                            /*
                             * calculating distance between user's coordinate with this.user's coordinates.
                             */
                            distance = getDistanceFromLatLonInKm(userLat, userLon, user.getLatitude(),
                                    user.getLongitude());
                            if (distance <= 1) {
                                countBy1KM++;
                                knownUserFor1.add(user);
                            }
                            if (distance <= 10) {
                                countBy10KM++;
                                knownUserFor10.add(user);
                            }
                            if (distance <= 100) {
                                countBy100KM++;
                                knownUserFor100.add(user);
                            }
                            if (distance <= 1000) {
                                countBy1000KM++;
                                knownUserFor1000.add(user);
                            }
                            if (distance <= 10000) {
                                countBy10000KM++;
                                knownUserFor10000.add(user);
                            }
                            break;
                        }
                    }
                }
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        // Categorizing users with respect to their distance.
        if (countBy1KM != 0) {
            CountByDistance distance1 = new CountByDistance(1, countBy1KM);
            distance1.setKnownUsers(new ArrayList<TwitterResult>(knownUserFor1));

            twitterUsers.setByDistanceOne(distance1);
        }
        if (countBy10KM != 0) {
            CountByDistance distance10 = new CountByDistance(10, countBy10KM);
            distance10.setKnownUsers(new ArrayList<TwitterResult>(knownUserFor10));

            twitterUsers.setByDistanceTen(distance10);
        }
        if (countBy100KM != 0) {
            CountByDistance distance100 = new CountByDistance(100, countBy100KM);
            distance100.setKnownUsers(new ArrayList<TwitterResult>(knownUserFor100));

            twitterUsers.setByDistanceHundred(distance100);
        }
        if (countBy1000KM != 0) {
            CountByDistance distance1000 = new CountByDistance(1000, countBy1000KM);
            distance1000.setKnownUsers(new ArrayList<TwitterResult>(knownUserFor1000));

            twitterUsers.setByDistanceThousand(distance1000);
        }
        if (countBy10000KM != 0) {
            CountByDistance distance10000 = new CountByDistance(10000, countBy10000KM);
            distance10000.setKnownUsers(new ArrayList<TwitterResult>(knownUserFor10000));

            twitterUsers.setByDistanceTenThousand(distance10000);
        }
        if (unknown != 0) {
            CountByDistance unknownDistance = new CountByDistance(-1, unknown);
            unknownDistance.setUnknownUsers(new ArrayList<TwitterResult>(unknownUser));

            twitterUsers.setUnknownUsers(unknownDistance);
        }
        return twitterUsers;
    }

    /**
     * Gets the distance between coordinates(lat lon) in km.
     * 
     * @param lat1 the lat1
     * @param lon1 the lon1
     * @param lat2 the lat2
     * @param lon2 the lon2
     * @return the distance from lat lon in km
     */
    private double getDistanceFromLatLonInKm(double lat1, double lon1, double lat2, double lon2) {

        long R = 6371; // Radius of the earth in km
        double dLat = deg2rad(lat2 - lat1); // deg2rad below
        double dLon = deg2rad(lon2 - lon1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2))
                * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        double d = R * c; // Distance in km
        return d;
    }

    /**
     * Converts Degrees to Radians.
     * 
     * @param deg the deg
     * @return the double
     */
    private double deg2rad(double deg) {
        return deg * (Math.PI / 180);
    }
}
