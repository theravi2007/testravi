package de.i2v.ws.entity;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class CodeFlower {

    private String name;
    private Integer size;
    private List<AppResult> children;

    @JsonProperty("name")
    public String getI2V() {
        return name;
    }

    public void setI2V(String name) {
        this.name = name;
    }

    public Integer getSize() {
        return size;
    }

    public void setSize(Integer size) {
        this.size = size;
    }

    @JsonProperty("children")
    public List<AppResult> getAppResult() {
        return children;
    }

    public void setAppResult(List<AppResult> children) {
        this.children = children;
    }

    @Override
    public String toString() {
        return "{name=" + name + ", size=" + size + ", children=" + children + "}";
    }

}
