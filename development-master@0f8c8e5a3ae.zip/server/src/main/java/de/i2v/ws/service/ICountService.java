package de.i2v.ws.service;

import java.net.URISyntaxException;
import java.sql.SQLException;
import java.util.Set;

public interface ICountService {

    boolean saveCount(Set<String> keywordList, String channel, String countFor) throws Exception, URISyntaxException,
            SQLException;

}
