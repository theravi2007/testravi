package de.i2v.ws.service.impl;

import de.i2v.ws.config.DatabaseConnection;
import de.i2v.ws.service.IShare;
import org.springframework.stereotype.Service;

import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Service
public class ShareImpl implements IShare {

    static Connection connection;

    // @Override
    // public Share getLinkByShareApp(String applicationName, String shareID) throws Exception {
    //
    // connection = Main.getConnection();
    // System.out.println("CONNECTED");
    //
    // String query = "Select * from count_detail where channel='" + applicationName + "' and \"shareIDP\"='"
    // + shareID + "'";
    // ResultSet resultSet = connection.createStatement().executeQuery(query);
    // Share share = new Share();
    // while (resultSet.next()) {
    //
    // share.setShareIDP(resultSet.getString("shareID"));
    // share.setNetwork(resultSet.getString("network"));
    // share.setUrl(resultSet.getString("url"));
    // System.out.println(share);
    // }
    // connection.close();
    // return share;
    // }

    @Override
    public boolean saveSocialKeyShare(String networkName, String url, List<String> keys) throws Exception {

        System.out.println("saveSocialKeyShare");

        try {
            connection = DatabaseConnection.getConnection();

            // check out for the Key first in KeywordNetwork set
            for (String key : keys) {
                addUpdateKey(key, networkName);
            }

        } catch (Exception exception) {
            System.err.println("save Social failed: " + exception);
        } finally {
            connection.close();
        }
        return true;
    }

    private void addUpdateKey(String keyward, String channel) throws URISyntaxException, SQLException {

        try {
            connection = DatabaseConnection.getConnection();

            // check for key existence
            System.out.println("check for key existence");
            PreparedStatement checkStatement = connection
                    .prepareStatement("Select * from count_detail where keyward=? and channel=?");
            checkStatement.setString(1, keyward);
            checkStatement.setString(2, channel);
            ResultSet resultSet = checkStatement.executeQuery();
            if (resultSet.next()) {
                // if exists. then update
                System.out.println("if exists. then update: " + keyward);
                int count = resultSet.getInt("share_count");
                count++;
                String sql = "UPDATE count_detail set share_count=? WHERE keyward=? and channel=?";
                checkStatement = connection.prepareStatement(sql);
                checkStatement.setInt(1, count);
                checkStatement.setString(2, keyward);
                checkStatement.setString(3, channel);

                checkStatement.execute();
            } else {
                // if not. then add
                System.out.println("if not. then add: " + keyward);
                PreparedStatement insertStatement = connection
                        .prepareStatement("INSERT INTO count_detail VALUES (?, ?, ?)");
                insertStatement.setString(1, keyward);
                insertStatement.setString(2, channel);
                insertStatement.setInt(3, 1);
                insertStatement.executeUpdate();
            }

        } catch (Exception exception) {
            System.err.println("addUpdateKey failed: " + exception);
        } finally {
            connection.close();
        }
    }
}
