package de.i2v.ws.service.impl;

import de.i2v.ws.config.DatabaseConnection;
import de.i2v.ws.service.ISearchService;
import org.springframework.stereotype.Service;

import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@Service
public class SearchServiceImpl implements ISearchService {

    static Connection connection;

    @Override
    public boolean saveSearchCount(String keyword) throws Exception, URISyntaxException, SQLException {
        try {
            connection = DatabaseConnection.getConnection();

            // check for key existence
            PreparedStatement checkStatement = connection
                    .prepareStatement("Select * from search_detail where search_keyword like ?");
            checkStatement.setString(1, "%" + keyword + "%");
            ResultSet resultSet = checkStatement.executeQuery();

            if (resultSet.next()) {
                // if exists. then update
                System.out.println("if exists. then update: " + keyword);
                int count = resultSet.getInt("search_count");
                count++;
                String sql = "UPDATE search_detail set search_count=? WHERE search_keyword like ?";
                checkStatement = connection.prepareStatement(sql);
                checkStatement.setInt(1, count);
                checkStatement.setString(2, "%" + keyword + "%");

                checkStatement.execute();
            } else {
                // if not. then add
                System.out.println("if not. then add: " + keyword);
                PreparedStatement insertStatement = connection
                        .prepareStatement("INSERT INTO search_detail VALUES ((SELECT count(search_id) FROM search_detail)+1, ?, ?)");
                // insertStatement.setInt(1, 1);
                insertStatement.setString(1, keyword);
                insertStatement.setInt(2, 1);
                insertStatement.executeUpdate();
            }

        } catch (Exception e) {
            System.err.println("saveSearchCount failed: " + e);
        } finally {
            connection.close();
        }
        return true;
    }

}
