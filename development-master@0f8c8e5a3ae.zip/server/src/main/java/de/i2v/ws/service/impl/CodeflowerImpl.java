package de.i2v.ws.service.impl;

import de.i2v.ws.config.DatabaseConnection;
import de.i2v.ws.entity.AppResult;
import de.i2v.ws.entity.CodeFlower;
import de.i2v.ws.entity.HitbackResult;
import de.i2v.ws.service.ICodeflower;
import org.springframework.stereotype.Service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Service
public class CodeflowerImpl implements ICodeflower {

    static Connection connection;

    @Override
    public CodeFlower generateSharingCodeflower() throws Exception {
        CodeFlower codeFlower = null;
        try {
            connection = DatabaseConnection.getConnection();

            System.out.println("GeneratingSharingCodeFlower");

            String searchQuery = "select * from search_detail";
            PreparedStatement checkStatement = connection.prepareStatement(searchQuery);

            ResultSet resultSet = checkStatement.executeQuery();
            if (resultSet == null) {
                throw new Exception("No Data found");
            }
            List<AppResult> appResultList = new ArrayList<AppResult>();

            while (resultSet.next()) {

                int search_id = resultSet.getInt("search_id");
                String search_keyword = resultSet.getString("search_keyword");
                int search_count = resultSet.getInt("search_count");

                AppResult appResult = new AppResult();
                appResult.setSearch_id(search_id);
                appResult.setName(search_keyword);
                appResult.setSize(search_count);

                appResultList.add(appResult);
            }
            /**
             * getChannelResult for facebook, twitter, g+, printrest,
             */
            Iterator<AppResult> iterator = appResultList.iterator();
            while (iterator.hasNext()) {
                System.out.println(iterator.next().toString());
            }

            AppResult facebookResult = getChannelResult("facebook");
            if (facebookResult != null) {
                appResultList.add(facebookResult);
            }
            AppResult twitterResult = getChannelResult("twitter");
            if (twitterResult != null) {
                appResultList.add(twitterResult);
            }
            AppResult googleResult = getChannelResult("google");
            if (googleResult != null) {
                appResultList.add(googleResult);
            }

            Iterator<AppResult> iterator1 = appResultList.iterator();
            while (iterator1.hasNext()) {
                System.out.println(iterator1.next().toString());
            }
            /**
             * Final result
             */
            codeFlower = new CodeFlower();
            codeFlower.setI2V("Idea 2 Validate Application");
            codeFlower.setAppResult(appResultList);
        } catch (Exception exception) {

        } finally {
            System.out.println("Closing connection");
            connection.close();
        }

        return codeFlower;
    }

    private AppResult getChannelResult(String channelName) throws Exception {
        AppResult appResult = null;
        try {
            connection = DatabaseConnection.getConnection();
            System.out.println("getChannelResult: " + channelName);
            String countQuery = "SELECT *  FROM count_detail where channel='" + channelName + "'";
            PreparedStatement checkStatement = connection.prepareStatement(countQuery);
            ResultSet resultSet = checkStatement.executeQuery();

            List<HitbackResult> hitbackResults = new ArrayList<HitbackResult>();
            while (resultSet.next()) {
                System.out.println("while: " + channelName);
                String keyword = resultSet.getString("keyword");
                int hb_count = resultSet.getInt("hb_count");

                HitbackResult hitbackResult = new HitbackResult();

                hitbackResult.setName(keyword);
                hitbackResult.setSize(hb_count);

                hitbackResults.add(hitbackResult);
            }

            if (hitbackResults.size() <= 0) {
                System.out.println(channelName + " result not found");
                return null;
            }
            appResult = new AppResult();
            appResult.setName(channelName);
            appResult.setHitbackResult(hitbackResults);
        } catch (Exception exception) {
            System.err.println("get channel Result failed: " + exception);
        } finally {
            connection.close();
        }

        return appResult;
    }
}
