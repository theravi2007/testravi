package de.i2v.ws.entity;

public class SearchDetail {

    private int searchId;
    private String search_keyword;
    private int searchcount;

    public int getSearchId() {
        return searchId;
    }

    public void setSearchId(int searchId) {
        this.searchId = searchId;
    }

    public String getSearch_keyword() {
        return search_keyword;
    }

    public void setSearch_keyword(String search_keyword) {
        this.search_keyword = search_keyword;
    }

    public int getSearchcount() {
        return searchcount;
    }

    public void setSearchcount(int searchcount) {
        this.searchcount = searchcount;
    }

    @Override
    public String toString() {
        return "SearchDetail [searchId=" + searchId + ", search_keyword=" + search_keyword + ", searchcount="
                + searchcount + "]";
    }
}