package de.i2v.ws.twitter.domain;

public class TwitterUsers {

    private CountByDistance byDistanceOne;
    private CountByDistance byDistanceTen;
    private CountByDistance byDistanceHundred;
    private CountByDistance byDistanceThousand;
    private CountByDistance byDistanceTenThousand;
    private CountByDistance unknownUsers;

    public CountByDistance getByDistanceOne() {
        return byDistanceOne;
    }

    public void setByDistanceOne(CountByDistance byDistanceOne) {
        this.byDistanceOne = byDistanceOne;
    }

    public CountByDistance getByDistanceTen() {
        return byDistanceTen;
    }

    public void setByDistanceTen(CountByDistance byDistanceTen) {
        this.byDistanceTen = byDistanceTen;
    }

    public CountByDistance getByDistanceHundred() {
        return byDistanceHundred;
    }

    public void setByDistanceHundred(CountByDistance byDistanceHundred) {
        this.byDistanceHundred = byDistanceHundred;
    }

    public CountByDistance getByDistanceThousand() {
        return byDistanceThousand;
    }

    public void setByDistanceThousand(CountByDistance byDistanceThousand) {
        this.byDistanceThousand = byDistanceThousand;
    }

    public CountByDistance getByDistanceTenThousand() {
        return byDistanceTenThousand;
    }

    public void setByDistanceTenThousand(CountByDistance byDistanceTenThousand) {
        this.byDistanceTenThousand = byDistanceTenThousand;
    }

    public CountByDistance getUnknownUsers() {
        return unknownUsers;
    }

    public void setUnknownUsers(CountByDistance unknownUsers) {
        this.unknownUsers = unknownUsers;
    }

    @Override
    public String toString() {
        return "TwitterUsers [byDistanceOne=" + byDistanceOne + ", byDistanceTen=" + byDistanceTen
                + ", byDistanceHundred=" + byDistanceHundred + ", byDistanceThousand=" + byDistanceThousand
                + ", byDistanceTenThousand=" + byDistanceTenThousand + ", unknownUsers=" + unknownUsers + "]";
    }

}
