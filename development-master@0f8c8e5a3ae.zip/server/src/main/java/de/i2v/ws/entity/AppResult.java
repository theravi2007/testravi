package de.i2v.ws.entity;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

public class AppResult {

    private Integer search_id;
    private String name;
    private Integer size;
    private List<HitbackResult> children;

    public Integer getSearch_id() {
        return search_id;
    }

    public void setSearch_id(Integer search_id) {
        this.search_id = search_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getSize() {
        return size;
    }

    public void setSize(Integer size) {
        this.size = size;
    }

    @JsonProperty("children")
    public List<HitbackResult> getHitbackResult() {
        return children;
    }

    public void setHitbackResult(List<HitbackResult> children) {
        this.children = children;
    }

    @Override
    public String toString() {
        return "{name=" + name + ", size=" + size + ", children=" + children + "}";
    }

}
