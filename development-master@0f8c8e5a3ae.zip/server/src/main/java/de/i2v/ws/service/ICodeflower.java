package de.i2v.ws.service;

import de.i2v.ws.entity.CodeFlower;

public interface ICodeflower {

    CodeFlower generateSharingCodeflower() throws Exception;
}
