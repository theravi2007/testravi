package de.i2v.ws.facebook;
public class FacebookQueryDTO implements Comparable<FacebookQueryDTO> {
	private String postId;
	private int likesCount;
	private int weight;
	private int commentsCount;
	private int sharesCount;
	private String userName;
	private String pageName;
	private String picture;
	private String statusMessage;
	private String statusUrl;
	private int from;
	private int shares;
	private int distance;

	private Double Longitude;
	private Double Latitude;
	private String City;
	private String Country;
	private int Sort;

	public int getSort() {
		return Sort;
	}

	public void setSort(int Sort) {
		this.Sort = Sort;
	}

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}

	public int getDistance() {
		return distance;
	}

	public void setDistance(int distance) {
		this.distance = distance;
	}

	public String getCountry() {
		return Country;
	}

	public void setCountry(String Country) {
		this.Country = Country;
	}

	public String getCity() {
		return City;
	}

	public void setCity(String City) {
		this.City = City;
	}

	public Double getLongitude() {
		return Longitude;
	}

	public void setLongitude(Double Longitude) {
		this.Longitude = Longitude;
	}

	public Double getLatitude() {
		return Latitude;
	}

	public void setLatitude(Double Latitude) {
		this.Latitude = Latitude;
	}

	public String getpostId() {
		return postId;
	}

	public void setpostId(String postId) {
		this.postId = postId;
	}

	public int getLikesCount() {
		return likesCount;
	}

	public void setLikesCount(int likesCount) {
		this.likesCount = likesCount;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	public String getPicture() {
		return picture;
	}

	public int getSharesCount() {
		return sharesCount;
	}

	public void setSharesCount(int sharesCount) {
		this.sharesCount = sharesCount;
	}

	public int getCommentsCount() {
		return commentsCount;
	}

	public void setCommentsCount(int commentsCount) {
		this.commentsCount = commentsCount;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPageName() {
		return pageName;
	}

	public void setPageName(String pageName) {
		this.pageName = pageName;
	}

	public int compareTo(FacebookQueryDTO facebookQueryDTO) {
		int returnCheck = 0;
		if (this.getSort() == 0) {
			if (this.getCommentsCount() < facebookQueryDTO.getCommentsCount())
				returnCheck = 1;
			else if (this.getCommentsCount() > facebookQueryDTO
					.getCommentsCount())
				returnCheck = -1;
			else {
				if (this.getLikesCount() < facebookQueryDTO.getLikesCount()) {
					returnCheck = 1;
				} else if (this.getLikesCount() > facebookQueryDTO
						.getLikesCount()) {
					returnCheck = -1;
				} else {
					returnCheck = 0;
				}
			}
		} else if (this.getSort() == 1) {
			if (this.getLikesCount() < facebookQueryDTO.getLikesCount())
				returnCheck = 1;
			else if (this.getLikesCount() > facebookQueryDTO.getLikesCount())
				returnCheck = -1;
			else {
				if (this.getCommentsCount() < facebookQueryDTO
						.getCommentsCount()) {
					returnCheck = 1;
				} else if (this.getCommentsCount() > facebookQueryDTO
						.getCommentsCount()) {
					returnCheck = -1;
				} else {
					returnCheck = 0;
				}
			}
		} else if (this.getSort() == 2) {
			if (this.getWeight() < facebookQueryDTO.getWeight())
				returnCheck = 1;
			else if (this.getWeight() > facebookQueryDTO.getWeight())
				returnCheck = -1;
			else {
				if (this.getCommentsCount() < facebookQueryDTO
						.getCommentsCount()) {
					returnCheck = 1;
				} else if (this.getCommentsCount() > facebookQueryDTO
						.getCommentsCount()) {
					returnCheck = -1;
				} else {
					returnCheck = 0;
				}
			}
		}
		return returnCheck;
	}

	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

	public String getStatusUrl() {
		return statusUrl;
	}

	public void setStatusUrl(String statusUrl) {
		this.statusUrl = statusUrl;
	}

	public int getFrom() {
		return from;
	}

	public void setFrom(int from) {
		this.from = from;
	}

	public int getShares() {
		return shares;
	}

	public void setShares(int shares) {
		this.shares = shares;
	}

}