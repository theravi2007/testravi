# development #

Install docker for windows https://download.docker.com/win/stable/InstallDocker.msi

To get the command prompt, you should use sourcetree terminal button (Mingw32 git portable)
and you will need to have at least one clone or active git repository.

Before you could start please check if all components are installed correctly 

```
#!bash

$ git --version
$ docker -v
$ docker-compose -v 
```

If you get a version number for all componets then the installation was completed sucessfull. You can now move on, with the clone of the code to our local machine.

```
#!bash

$ mkdir idea2validate
$ git clone https://bitbucket.org/idea2validate/development.git idea2validate ; cd idea2validate
```

The repository is splitted into submodules, the submodule need to be linked to your repository locally, this could be acomplished by 

```
#!bash

$ git submodule init ; git submodule update 
```

Update Submodules status and clone the code.

```
#!bash

$ git submodule foreach git pull origin master
```

Now you could test your environment with docker. Go to root folder of the development repository and start the docker servers. 


Start your local environment

```
#!bash

$ docker-compose up -d --build
```



Stoping and Deleting Docker-Compose

```
#!bash

$ docker-compose stop ; docker-compose rm -f
```

Test the application

```
https://localhost:8443/ 
or
http://localhost
```

Sep up your development environment. Develop. Deploy to target folder. 

If you make changes on the server code please don't forget to create the *.war file

```
mvn clean install
```
Rebuild the docker container with your changes

Stoping and Deleting Docker-Compose

```
#!bash

$ docker-compose stop ; docker-compose rm -f
```

Rebuild the docker-com

```
#!bash

$ docker-compose up -d --build
```
Test it.

Commit your changes


```
#!bash

#Git push submodule
git push --recurse-submodules=on-demand
cd /server
git checkout master
git merge 1732b5b (see message from git checkout)
```



Working in Progress

Check this part
```
#!bash

$ git submodule foreach npm install 
```

- Update submodules
- Update eclipse how to
- Update description of each specific line is doing

test
